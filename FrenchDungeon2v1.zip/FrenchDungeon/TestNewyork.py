from Modules import Script
import sys
import time
x='asdasd'
y=12

"""print('a', end='')
print('\033[{}C\033[1A'.format(len(x)+y))
print('a', end='')"""

print("lol")
raw_input()
from threading import Timer
answer = None
for letter in text:
    timeout = 0.1
    t = Timer(timeout, print, 'a')
    t.start()
    prompt = letter
    answer = input(prompt)
if answer != None:
    exit()
    t.cancel()