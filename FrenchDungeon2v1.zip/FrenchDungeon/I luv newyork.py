from tkinter import *
import sys
import winsound

sts = 'SoundEffect/startupsound'
def disable_event():
    pass

winsound.PlaySound(sts, winsound.SND_ASYNC)
wind = Tk()
wind.title("French Dungeon 2: The Return of Croissant")
wind.geometry('500x500')
wind.resizable(height = False, width = False)
icon = PhotoImage(file = 'Avocado.gif')
wind.iconphoto(False, icon)
logo = PhotoImage(file = "AvocadoL.gif")
logop = Label(image = logo)
logop.place(x=-2, y=0)
wind.protocol("WM_DELETE_WINDOW", disable_event)
wind.after(3500, lambda: wind.destroy())
wind.mainloop()