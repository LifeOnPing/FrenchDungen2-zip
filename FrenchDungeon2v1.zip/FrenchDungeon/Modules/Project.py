def mola(text, sigan):
    import time
    danu = text
    for char in danu:
        print(char, end='')
        time.sleep(sigan)
    return