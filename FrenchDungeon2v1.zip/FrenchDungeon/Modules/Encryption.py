def enc(Text, num, num2):
    outText = []
    cryptText = []
    uppercase = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    lowercase = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    number = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    for eachLetter in Text:
        if eachLetter in number:
            index = number.index(eachLetter)
            crypting = (index + num + num2 + 3)
            if crypting>8:
                while crypting>8:
                    crypting -= 9
            if crypting<0:
                while crypting<0:
                    crypting += 9
            cryptText.append(crypting)
            newLetter = number[crypting]
            outText.append(newLetter)
        elif eachLetter in uppercase:
            index = uppercase.index(eachLetter)
            crypting = (index + num + num2 + 5)
            if crypting>25:
                while crypting>25:
                    crypting -= 26
            if crypting<0:
                while crypting<0:
                    crypting += 26
            cryptText.append(crypting)
            newLetter = uppercase[crypting]
            outText.append(newLetter)
        elif eachLetter in lowercase:
            index = lowercase.index(eachLetter)
            crypting = (index + num2 + num + 9)
            if crypting>25:
                while crypting>25:
                    crypting -= 26
            if crypting<0:
                while crypting<0:
                    crypting += 26
            cryptText.append(crypting)
            newLetter = lowercase[crypting]
            outText.append(newLetter)
    return outText

def dec(Text, num, num2):
    outText = []
    cryptText = []
    uppercase = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    lowercase = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    number = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    for eachLetter in Text:
        if eachLetter in number:
            index = number.index(eachLetter)
            crypting = (index - num - num2 - 3)
            if crypting>8:
                while crypting>8:
                    crypting -= 9
            if crypting<0:
                while crypting<0:
                    crypting += 9
            cryptText.append(crypting)            
            newLetter = number[crypting]
            outText.append(newLetter)        
        elif eachLetter in uppercase:
            index = uppercase.index(eachLetter)
            crypting = (index - num - num2 - 5)
            if crypting>25:
                while crypting>25:
                    crypting -= 26
            if crypting<0:
                while crypting<0:
                    crypting += 26
            cryptText.append(crypting)
            newLetter = uppercase[crypting]
            outText.append(newLetter)
        elif eachLetter in lowercase:
            index = lowercase.index(eachLetter)
            crypting = (index - num2 - num - 9)
            if crypting>25:
                while crypting>25:
                    crypting -= 26
            if crypting<0:
                while crypting<0:
                    crypting += 26
            cryptText.append(crypting)
            newLetter = lowercase[crypting]
            outText.append(newLetter)
    return outText


def randompassword(length):
    import random
    import string
    letters = string.ascii_letters
    outText = ''.join(random.choice(letters) for i in range(length))
    return outText
