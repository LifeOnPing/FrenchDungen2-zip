def readtime(text, urt):
    tt = len(text)
    ratio = 7/30
    tr = ratio*tt
    drt = urt/9
    rt = ratio/drt
    abc = rt*tt
    return abc

