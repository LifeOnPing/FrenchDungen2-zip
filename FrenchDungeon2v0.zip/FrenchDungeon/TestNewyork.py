from Modules import Script
import sys
import time
Timeout = 30
end_time = time.time() + Timeout
while time.time() < end_time:
    res = input('What is your input: ')
    try:
        # process user input
        except SomeException:
        print('There was an error, try again.')
    else:
        break