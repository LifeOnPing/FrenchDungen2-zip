import urllib.request
import os
import time as jake
import tkinter



print('Installing mandatory file download for the game to run.....')

os.mkdir('./FrenchDungeon2')

main = 'https://drive.google.com/u/0/uc?id=1BsGrcm7PQCE22VyrpmGOGl0yv90wUwHo&export=download'
music1 = 'https://drive.google.com/u/0/uc?id=1T8Ads18wzNIZ9PjltjIZCjHU-pCA4HTk&export=download'
music2 = 'https://drive.google.com/u/0/uc?id=1dSHi8GlJ5Fw3nje3yp9nDWnW-al6wHR0&export=download'
md1 = 'https://drive.google.com/u/0/uc?id=14SMrt5wSiwQg0OV8RW9MbZPuIVZonJZc&export=download'
md2 = 'https://drive.google.com/u/0/uc?id=10kNHW0WUoW-zo1Ns8qT9H1CgATlOX9Ey&export=download'
se = 'https://drive.google.com/u/0/uc?id=1M9sJ2ZeNt6xGsQ3eIM6CWmibbqXWyDyC&export=download'

os.mkdir('./FrenchDungeon2/Music')
os.mkdir('./FrenchDungeon2/Password')
os.mkdir('./FrenchDungeon2/Username')
os.mkdir('./FrenchDungeon2/Modules')
os.mkdir('./FrenchDungeon2/SoundEffect')
os.mkdir('./FrenchDungeon2/Informations')
os.mkdir('./FrenchDungeon2/Others')
os.mkdir('./FrenchDungeon2/ProSave')
os.mkdir('./FrenchDungeon2/InvSave')

urllib.request.urlretrieve(main, 'FrenchDungeon2/French_Dungeon_2.py')
print('25%' + 'is done :) wait patiently')
urllib.request.urlretrieve(music1, 'FrenchDungeon2/Music/EndCredit.wav')
print('50%' + 'is done :) wait patiently')
urllib.request.urlretrieve(music2, 'FrenchDungeon2/Music/Frozen.wav')
print('Hello')
urllib.request.urlretrieve(md1, 'FrenchDungeon2/Modules/Encryption.py')
print('75%' + 'is done :) wait patiently')
urllib.request.urlretrieve(md2, 'FrenchDungeon2/Modules/conversion.py')
print('100%' + 'is done :) wait patiently')
urllib.request.urlretrieve(se, 'FrenchDungeon2/SoundEffect/Stab.wav')
print('2%' + 'is done :) wait patiently')

print("It's finished! :)")
jake.sleep(3)
