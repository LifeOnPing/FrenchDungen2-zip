import time
a = time.time()
time.sleep(3)
b = time.time()
c = b-a
print(c)