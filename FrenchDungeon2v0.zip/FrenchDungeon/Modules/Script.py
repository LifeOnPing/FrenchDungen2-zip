import time
import sys

def endc(moonjang):
    for moonja in moonjang:
        sys.stdout.write(moonja)
        sys.stdout.flush()
        time.sleep(0.1)

def die(moonjang):
    for moonja in moonjang:
        sys.stdout.write(moonja)
        sys.stdout.flush()
        time.sleep(0.7)

def game(sootja, moonjang):
    for moonja in moonjang:
        sys.stdout.write(moonja)
        sys.stdout.flush()
        time.sleep(sootja)
    print()
    
    
def check(text):
    from threading import Timer
    answer = None
    for letter in text:
        timeout = 0.1
        t = Timer(timeout, print, 'a')
        t.start()
        prompt = letter
        answer = input(prompt)
        if answer != None:
            exit()
        t.cancel()