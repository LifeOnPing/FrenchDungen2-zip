import random
import math

def oryu(a, b, c, d):
    OutText=None
    ee = random.randint(1, 3)
    if ee==1:
        e='J'
    if ee==2:
        e='L'
    if ee==3:
        e='T'
    else:
        e='E'
    OutText= str(a) + b + ' - ' + str(math.trunc(c)) + ' - ' + str(d) + e
    return OutText

def dev():
    print("N=Number \nL=Letter")
    print("Format of error is this > N1,L1 - N2 - N3,L2")
    print("For example, 1T - 15 - 0J")
    print("N1 = It is order of error, search 'errorsoonser = N1' to fix and see where error occured")
    print("L1 = Type of error, you can search what kind of error y typing letter on error code book in developer tool")
    print("N2 = It shows time passed after user executed the program")
    print("N3 = It shows stage save information")
    print("L2 = Person who need to fix that error. J-Jake L-Liam T-Tom E-Error during choosing person to fix in Error code generator.")
    print()
