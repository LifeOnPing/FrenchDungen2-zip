from Modules import Encryption as en

a = en.enc('z', 1, 3)
print(a)

b = en.dec(a, 1, 3)
print(b)