import math
import random
import time as tom
import string
import multiprocessing
from tkinter import *
import winsound
import os
import webbrowser as jake
from Modules import Encryption as eandc
from Modules import Conversion as conv
from Modules import ECG
from Modules import Script as sc
from Modules import InventorySave as ivs
import sys
import shutil

starttime = tom.time()

knifestab = 'SoundEffect/KnifeStab.wav'
slap = 'SoundEffect/Slap.wav'
sts = 'SoundEffect/Startup.wav'
loginsfx = 'SoundEffect/LoginSound.wav'
failfail = 'SoundEffect/Fail.wav'

myfavsong = 'Music/LetItGo.wav'
mtm = 'Music/LoveIsAnOpenDoor.wav'
endcredit = 'Music/Ending.wav'
bossm = 'Music/Boss1.wav'
tutm = 'Music/Tutorial.wav'
endcredit2 = 'Music/EndingSad.wav'
loginscreen = 'Music/Login.wav'
homemenu = 'Music/Home.wav'
ctm = 'Music/ChracterSong.wav'
sstm = 'Music/StoryMusic.wav'
onemusic = 'Music/FiveMusic.wav'
twomusic = 'Music/ThreeMusic.wav'
threemusic = 'Music/ThreeMusic.wav'
fourmusic = 'Music/FourMusic.wav'
fivemusic = 'Music/ThreeMusic.wav'
sixmusic = 'Music/SixMusic.wav'
sevenmusic = 'Music/SevenMusic.wav'

def fuckuser():
    pass

winsound.PlaySound(sts, winsound.SND_ASYNC)
wind = Tk()
wind.title("French Dungeon 2: The Return of Croissant")
wind.geometry('500x500')
wind.resizable(height = False, width = False)
icon = PhotoImage(file = 'Pictures/AvocadoI.gif')
wind.iconphoto(False, icon)
logo = PhotoImage(file = "Pictures/AvocadoL.gif")
logop = Label(image = logo)
logop.place(x=-2, y=0)
wind.protocol("WM_DELETE_WINDOW", fuckuser)
wind.after(7080, lambda: wind.destroy())
wind.mainloop()

user=None
currentdeveloper = ['Jake']
vvvvv=2.7
choice=0
weaponchoice=0
weapon='Patate'
damage=1
attS=1
attSE=1
hp=10
inventory = ['White Burgundy', 'White Burgundy', 'Red Burgundy']
damageincrease=5
poison=20
trollhp=5
trolldamage=1
trollattS=2
twochoicefirst=0
itemuse=0
trolldamage = float(trolldamage)
hp = float(hp)
trollhp = float(trollhp)
redb=30
whiteb=20
goldenchest = ['Red Burgundy']
silverchest = ['White Burgundy']
woodenchest = ['Burgundys Terroris', 'Red Burgundy']
tutorialman = 'Didacticiel Facile'
tutorialmanq = 'Didacticiel Facile:'
mayorq = 'French T.Oasty:'
mayor = 'French T.Oasty'
fatherq = 'Baguette Cantel:'
enemy = 'Potato'
bossmale = 'Patron'
chracter=None
stagesave=0
readv = None
neighbor = None

def readingtime():
    global readv
    global stagesave
    readv = 0.075
    print("Customize your reading speed")
    readvv = None
    sc.game(readv, "Do you like the speed of this text? Press '1' to use this speed and use '+' to speed up and '-' to slow down the text speed.")
    readvv = input("")
    while readvv!='1':
        sc.game(readv, "Enter '+' to speed up, '-' to slow down and '1' to confirm.")
        readvv = input("")
        if readvv=='-':
            readv = readv * 1.2
        if readvv=='+':
            readv = readv * 0.8
        else:
            sc.game(readv, "Type valid answer.")
    sc.game(readv, "The speed has been confirmed, you can't change it from now on.")
    stagesave = 0.1
    ssg = open('ProSave/a' + username + 'ps.txt', 'w')
    ssg.write(str(ssg))
    ssg.close()
    rt = open('Others/a' + username + 'rt.txt', 'w')
    rt.write(str(readv))
    rt.close()
    tutorial()


def tutorial():
    winsound.PlaySound(tutm, winsound.SND_ASYNC + winsound.SND_LOOP)
    sc.game(readv, tutorialmanq + " Do you want to skip the tutorial or view specific parts? \nlist: \n1)Skip \n2)Dialogue \n3)Multichoice Answers \n4)Inventory \n5)Items \n6)Battling \n7)I want to view the whole tutorial")
    skiptutorial = input("")
    if skiptutorial=='1':
        print()
        chracterselect()
    elif skiptutorial=='2':
        tutorialdialogue()
    elif skiptutorial=='3':
        tutorialmultichoice()
    elif skiptutorial=='4':
        tutorialinv()
    elif skiptutorial=='5':
        tutorialitems()
    elif skiptutorial=='6':
        tutorialbattle()
    else:
        sc.game(readv, tutorialmanq + " Hello " + user + " my name is " + tutorialman)
        sc.game(readv, tutorialmanq + " I am going to introduce you to this game.")
        sc.game(readv, tutorialmanq + " I will first teach you about Dialogue")
        sc.game(readv, tutorialmanq + " Whenever a character talks to you their name will show up here.")
        print("        ↑        ")
        sc.game(readv, tutorialmanq + " When the user is prompted to do something, no name will show up")
        sc.game(readv, "This is what it will look like")
        sc.game(readv, tutorialmanq + " Now I will teach you about Multi Choice Answers")
        sc.game(readv, tutorialmanq + " In this game, you select whatever you want.")
        sc.game(readv, tutorialmanq + " Choices that can be selected by you will show up like this")
        sc.game(readv, "1)a \n2)b \n3)c")
        sc.game(readv, tutorialmanq + " Now let's actually try one.")
        sc.game(readv, tutorialmanq + " Which desert do you like most \n1)Chocolate \n2)Baguette \n3)Cantel \n4)Avocado")
        tutorialselectionfood = input("")
        if tutorialselectionfood=='1':
            tutorialselectionfood = 'Chocolate'
        elif tutorialselectionfood=='2':
            tutorialselectionfood = 'Baguette'
        elif tutorialselectionfood=='3':
            tutorialselectionfood = 'Cantel'
        elif tutorialselectionfood=='4':
            tutorialselectionfood = 'Avocado'
        else:
            while tutorialselectionfood!='1' and tutorialselectionfood!='2' and tutorialselectionfood!='3' and tutorialselectionfood!='4':
                sc.game(readv, "Choose a valid answer")
                sc.game(readv, tutorialmanq + " Which desert do you like most \n1)Chocolate \n2)Baguette \n3)Cantel \n4)Avocado")
                tutorialselectionfood = input("")
                if tutorialselectionfood=='1':
                    tutorialselectionfood = 'Chocolate'
                elif tutorialselectionfood=='2':
                    tutorialselectionfood = 'Baguette'
                elif tutorialselectionfood=='3':
                    tutorialselectionfood = 'Cantel'
                elif tutorialselectionfood=='4':
                    tutorialselectionfood = 'Avocado'
    sc.game(readv, tutorialmanq + " You selected " + tutorialselectionfood + " That is a cool choice")
    sc.game(readv, tutorialmanq + " Now I will teach you about the inventory system")
    sc.game(readv, tutorialmanq + " When you want to use something in your inventory you must type the items name like this")
    sc.game(readv, "Red Burgundy")
    sc.game(readv, tutorialmanq + " This will casue the item to be used for its intended effect and therefore removed from your inventory")
    sc.game(readv, tutorialmanq + " Now I will teach you about Items")
    sc.game(readv, tutorialmanq + " HP is your Health")
    sc.game(readv, tutorialmanq + " If you get attacked by an enemy your health will drop depending on how much damage it does")
    sc.game(readv, tutorialmanq + " When you lose health you will hear this sound")
    winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
    tom.sleep(1.5)
    sc.game(readv, tutorialmanq + " Your attack speed tells you how fast you can attack")
    sc.game(readv, tutorialmanq + " The higher the value the faster you can attck")
    sc.game(readv, tutorialmanq + " Weapons have a set amount of damage that they can do")
    sc.game(readv, tutorialmanq + " Each weapons damage has been randomly selected")
    sc.game(readv, tutorialmanq + " Depending on the weapon depends on how much damage it will do")
    sc.game(readv, tutorialmanq + " The potions will have either a negative or positive effect")
    sc.game(readv, tutorialmanq + " Red Burgundy will heal you by 4HP")
    sc.game(readv, tutorialmanq + " White Burgundy will deal 4HP to either you or the enemy")
    sc.game(readv, tutorialmanq + " Burgundy's Terroris will increase the damage you do by +5")
    sc.game(readv, tutorialmanq + " Now I will tell you about Battling")
    sc.game(readv, tutorialmanq + " In a battle you will fight against the enemy")
    sc.game(readv, tutorialmanq + " You will attack the enemy with your chosen weapon")
    sc.game(readv, tutorialmanq + " If the enemy kills you its 'GAME OVER'")
    sc.game(readv, tutorialmanq + " In every battle you do you will have 3 options to choose from")
    sc.game(readv, tutorialmanq + " The options you can choose are")
    sc.game(readv, tutorialmanq + "\n1)Attack\n2)Run away\n3)Use item in inventory")
    sc.game(readv, tutorialmanq + " If you choose to attack you will do the amount of damage that your current weapon does")
    sc.game(readv, tutorialmanq + " If you choose to run away, you will die")
    sc.game(readv, tutorialmanq + " When you use an item in your inventory, it will have either a negative or positive effect on you")
    chracterselect()

def tutorialdialogue():
    sc.game(readv, tutorialmanq + " OK, I will now teach you about Dialogue")
    sc.game(readv, tutorialmanq + " Whenever a character talks to you their name will show up here.")
    print("        ↑        ")
    sc.game(readv, tutorialmanq + " When the user is prompted to do something, no name will show up")
    sc.game(readv, "This is what it will look like")
    tutorial()


def tutorialmultichoice():
    sc.game(readv, tutorialmanq + " OK, I will now teach you about Multi Choice Answers")
    sc.game(readv, tutorialmanq + " In this game, you select whatever you want.")
    sc.game(readv, tutorialmanq + " Choices that can be selected by you will show up like this")
    sc.game(readv, "1)a \n2)b \n3)c")
    sc.game(readv, tutorialmanq + " Now let's actually try one.")
    sc.game(readv, tutorialmanq + " Which desert do you like most \n1)Chocolate \n2)Baguette \n3)Cantel \n4)Avocado")
    tutorialselectionfood = input("")
    if tutorialselectionfood=='1':
        tutorialselectionfood = 'Chocolate'
    elif tutorialselectionfood=='2':
        tutorialselectionfood = 'Baguette'
    elif tutorialselectionfood=='3':
        tutorialselectionfood = 'Cantel'
    elif tutorialselectionfood=='4':
        tutorialselectionfood = 'Avocado'
    else:
        while tutorialselectionfood!='1' and tutorialselectionfood!='2' and tutorialselectionfood!='3' and tutorialselectionfood!='4':
            sc.game(readv, "Choose a valid answer")
    
            sc.game(readv, tutorialmanq + " Which desert do you like most \n1)Chocolate \n2)Baguette \n3)Cantel \n4)Avocado")
            tutorialselectionfood = input("")
            if tutorialselectionfood=='1':
                tutorialselectionfood = 'Chocolate'
            elif tutorialselectionfood=='2':
                tutorialselectionfood = 'Baguette'
            elif tutorialselectionfood=='3':
                tutorialselectionfood = 'Cantel'
            elif tutorialselectionfood=='4':
                tutorialselectionfood = 'Avocado'
    sc.game(readv, tutorialmanq + " You selected " + tutorialselectionfood + " That is a cool choice")
    sc.game(readv, tutorialmanq + "Now I will teach you about the inventory system")
    sc.game(readv, tutorialmanq + " When you want to use something in your inventory you must type the items name like this")
    sc.game(readv, "Red Burgundy")
    sc.game(readv, tutorialmanq + " This will casue the item to be used for its intended effect and therefore removed from your inventory")
    tutorial()


def tutorialinv():
    sc.game(readv, tutorialmanq + " OK , I will now teach you about the Inventory system")
    sc.game(readv, tutorialmanq + " When you want to use something in your inventory you must type the items name like this")
    sc.game(readv, "Red Burgundy")
    sc.game(readv, tutorialmanq + " This will casue the item to be used for its intended effect and therefore removed from your inventory")
    tutorial()


def tutorialitems():
    sc.game(readv, tutorialmanq + " OK, I will now teach you about Items")
    sc.game(readv, tutorialmanq + " HP is your Health")
    sc.game(readv, tutorialmanq + " If you get attacked by an enemy your health will drop depending on how much damage it does")
    sc.game(readv, tutorialmanq + " When you lose health you will hear this sound")
    winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
    tom.sleep(1.5)
    sc.game(readv, tutorialmanq + " Your attack speed tells you how fast you can attack")
    sc.game(readv, tutorialmanq + " The higher the value the faster you can attck")
    sc.game(readv, tutorialmanq + " Weapons have a set amount of damage that they can do")
    sc.game(readv, tutorialmanq + " Each weapons damage has been randomly selected")
    sc.game(readv, tutorialmanq + " Depending on the weapon depends on how much damage it will do")
    sc.game(readv, tutorialmanq + " The potions will have either a negative or positive effect")
    sc.game(readv, tutorialmanq + " Red Burgundy will heal you by 4HP")
    sc.game(readv, tutorialmanq + " White Burgundy will deal 4HP to either you or the enemy")
    sc.game(readv, tutorialmanq + " Burgundy's Terroris will increae the damage you do by +5")
    tutorial()


def tutorialbattle():
    sc.game(readv, tutorialmanq + " OK, I will now teach you about Battling")
    sc.game(readv, tutorialmanq + " In a battle you will fight against the enemy")
    sc.game(readv, tutorialmanq + " You will attack the enemy with your chosen weapon")
    sc.game(readv, tutorialmanq + " If the enemy kills you its 'GAME OVER'")
    sc.game(readv, tutorialmanq + " In every battle you do you will have 3 options to choose from")
    sc.game(readv, tutorialmanq + " The options you can choose are")
    sc.game(readv, tutorialmanq + "\n1)Attack\n2)Run away\n3)Use item in inventory")
    sc.game(readv, tutorialmanq + " If you choose to attack you will do the amount of damage that your current weapon does")
    sc.game(readv, tutorialmanq + " If you choose to run away, you will die")
    sc.game(readv, tutorialmanq + " When you use an item in your inventory, it will have either a negative or positive effect on you")
    chracterselect()


def chracterselect():
    global hp
    global inventory
    global chracter
    global neighbor
    global chracterquote    
    global neighborquote
    global chractername
    global stagesave
    winsound.PlaySound(None, winsound.SND_ASYNC)
    winsound.PlaySound(ctm, winsound.SND_ASYNC + winsound.SND_LOOP)
    while chracter!='1' and chracter!='2':
        sc.game(readv, "Which character do you want to play as?")
        sc.game(readv, "1)Croissant Chocolat Cantel\n2)Ficelle Cantel")
        chracter = input("")
    else:
        if chracter=='1':
            sc.game(readv, "You have selected 'Croissant Chocolat Cantel' as your chracter \n")
            hp=100
            inventory = ['Red Burgundy', 'White Burgundy']
            chracterquote='Croissant:'
            neighbor='Ahh Choux'
            neighborquote='Ahh Choux:'
            chractername='Croissant'
        if chracter=='2':
            sc.game(readv, "You have selected 'Ficelle Cantel' as your chracter \n")
            hp=80
            inventory = ['Red Burgundy', 'White Burgundy', "Burgundy's Terroris"]
            chracterquote='Ficelle:'
            neighbor='Biscotti Fontina'
            neighborquote='Bicotti Fontina:'
            chractername='Ficelle'
        stagesave = 0.2
        ssg = open('ProSave/a' + username + 'ps.txt', 'w')
        ssg.write(str(ssg))
        ssg.close()
        nb = open('Informations/a' + username + 'nb.txt', 'w')
        nb.write(neighbor)
        nb.close()
        hhp = open('Informations/a' + username + 'hp.txt', 'w')
        hhp.write(str(hp))
        hhp.close()
        ivs.invsav(inventory, username)
        cc = open('Informations/a' + username + 'cc.txt', 'w')
        cc.write(chracter)
        cc.close()
        storystory()

def storystory():
    sc.game(readv, "Do you want to read the story about your dad? \n1)Yes, I want to read it. \n2)No, I want to skip it.")
    skipstory = input("")
    if skipstory=='2':
        print()
        storystorystory()
    elif skipstory=='1':
        print()
        sc.game(readv, "In a small town called Pont-Évêque.")
        sc.game(readv, "Baguette Cantel arrived many years ago.")
        sc.game(readv, "He had just escaped death in a dungeon in Ascot.")
        sc.game(readv, "He moved to Pont-Évêque and married Brioche Roquefort.")
        sc.game(readv, "They had two children, Croissant Chocolat Cantel and Ficelle Cantel.")
        sc.game(readv, "What you choose is up to you.")
        sc.game(readv, "Welcome to French Dungeon 2.")
        sc.game(readv, "The Return of " + chractername)
        print()
        storystorystory()
    else:
        sc.game(readv, "Choose something " + user)
        storystory()

def storystorystory():
    global stagesave
    stagesave=1
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    winsound.PlaySound(sstm, winsound.SND_ASYNC + winsound.SND_LOOP)
    sc.game(readv, mayorq + " Hello " + chractername + ", did you hear about the recent mysterious monster attacks from the dungeon?")
    sc.game(readv, "1)No I haven't heard about that \n2)Yes, that was outrageous")
    usersay = input("")
    if usersay=='1':
        sc.game(readv, chracterquote + " No I haven't heard about that")
        sc.game(readv, mayorq + " Well ok, I was going to ask you to help slay the monsters in the dungeon but if you haven't heard of it, that is okay.")
        sc.game(readv, "You failed to get a job from the mayor")
        failscreen2()
    elif usersay=='2':
        sc.game(readv, chracterquote + " Yes, that was outrageous")
        sc.game(readv, mayorq + " Yes it was, " + neighbor + " and your dad are currently missing")
        sc.game(readv, chracterquote + " Wait, is my dad missing too?")
        sc.game(readv, mayorq + " Yes Mr.Cantel is missing.")
        storystorystorystory()
    else:
        sc.game(readv, mayorq + " Hello? Are you ignoring me?")
        sc.game(readv, mayorq + " Just get out of my house " + chractername)
        sc.game(readv, "You have been kicked out of the " + mayor + "'s house")
        failscreen2()

def storystorystorystory():
    global stagesave
    stagesave=1.1
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    sc.game(readv, mayorq + " Do you wanna go in to the dungeon and save " + neighbor + " and your dad?")
    sc.game(readv, "1)Yes! I need to give my father another chance! \n2)No! My father was a bad man! I will never save him!")
    dungeonselect = input("")
    if dungeonselect=='1':
        sc.game(readv, chracterquote + " Yes! I need to give my father another chance!")
        sc.game(readv, mayorq + " Ok, go to " + tutorialman + ", he might help you prepare the dungeon")
        sc.game(readv, chracterquote + " Ok thank you Mr.Oasty")
        storystorystorystorystory()
    elif dungeonselect=='2':
        sc.game(readv, chracterquote + " No! My father was a bad man! I will never save him!")
        sc.game(readv, mayorq + " Do you not care about your dad?")
        sc.game(readv, mayorq + " That is disappoioting " + chractername + " I hate you!!!!")
        sc.game(readv, mayorq + " You have abandoned " + neighbor + " and your father.")
        failscreen2()
    else:
        sc.game(readv, mayorq + " Are you going to save them or not?")
        sc.game(readv, mayorq + " You know they might be dying in the dungeon right now.")
        sc.game(readv, mayorq + " Just get out...")
        sc.game(readv, "You have been kicked out of " + mayor + "'s house")
        failscreen2()
    
def storystorystorystorystory():
    global stagesave
    stagesave=1.2
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    sc.game(readv, "You headed to " + tutorialman + "'s house")
    sc.game(readv, tutorialmanq + " Hello again " + user)
    sc.game(readv, tutorialmanq + " Oh sorry it's " + chractername + " now")
    sc.game(readv, tutorialmanq + " So, what are you doing here?")
    sc.game(readv, "1)I need to go in to dungeon to save " + neighbor + " and my father. Can you help me? \n2)To chill out, wanna watch netflix?")
    userselectionone = input("")
    if userselectionone=='1':
        sc.game(readv, chracterquote + " I need to go in to the dungeon to save " + neighbor + " and my father. Can you help me?")
        sc.game(readv, tutorialmanq + " Of course I can " + chractername + '.')
        sixstories()
    if userselectionone=='2':
        sc.game(readv, chracterquote + " To chill out, wanna watch netflix?")
        sc.game(readv, tutorialmanq + " Nah, I wanna watch Disney plus.")
        winsound.PlaySound(myfavsong, winsound.SND_ASYNC | winsound.SND_ALIAS )
        sc.game(readv, "You watched Frozen 2 with " + tutorialman + ".")
        sc.game(readv, "You spent 20 minutes watching frozen 2 with " + tutorialman + ".")
        sc.game(readv, "You died because you were too old.")
        failscreen2()
    else:
        sc.game(readv, tutorialmanq + " I said what are you doing here!")
        winsound.PlaySound(slap, winsound.SND_ASYNC | winsound.SND_ALIAS)
        sc.game(readv, tutorialman + " slapped you so hard that you died")
        failscreen2()

def sixstories():
    global stagesave
    stagesave=1.3
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    sc.game(readv, tutorialmanq + "How can I help you " + chractername + "?")
    sc.game(readv, "1)What do I need to prepare? \n2)I just want to know where is the entrance of dungeon.")
    userselectiontwo = input("")
    if userselectiontwo=='1':
        sc.game(readv, chracterquote + " What do I need to prepare?")
        sc.game(readv, tutorialmanq + " Oh just couple of things, you will need bag with weapons and potions in it.")
        sc.game(readv, tutorialmanq + " Because you will meet monsters in the dungeon.")
        sc.game(readv, tutorialmanq + " Now go in and save your father and " + neighbor + "!")
        sc.game(readv, "You headed back to your house to prepare the dungeon trip \n")
        startingweapon()
    if userselectiontwo=='2':
        sevenstories()
    else:
        sc.game(readv, tutorialmanq + " Hello? \nAre you okay? why are you just saying random thing?")
        sc.game(readv, tutorialmanq + " Just get out.")
        failscreen2()

def sevenstories():
    global stagesave
    stagesave=1.4
    ssg = open('ProSave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    sc.game(readv, chracterquote + " I just want to know where the entrance of the dungeon is.")
    sc.game(readv, tutorialmanq + " Oh the entrance is just behind my house. Is that all of you questions? Go in and save your father and " + neighbor + "!")
    sc.game(readv, "1)Yes, that is all. \n2)Actually I have one more question.")
    userselectionthree = input("")
    if userselectionthree=='1':
        sc.game(readv, chracterquote + " Yes, that is all.")
        sc.game(readv, tutorialmanq + " Perfect! Now go in and save your father and " + neighbor + "!")
        sc.game(readv, chracterquote + " Thank you " + tutorialman + " I will save " + neighbor + " and my father")
        sc.game(readv, "You headed back to your house to prepare the dungeon trip \n")
        startingweapon()
    if userselectionthree=='2':
        winsound.PlaySound(mtm, winsound.SND_ASYNC)
        sc.game(readv, chracterquote + " Actually I have one more question.")
        sc.game(readv, tutorialmanq + " I'm listening.")
        sc.game(readv, chracterquote + " Okay, can I just, say something crazy?")
        sc.game(readv, tutorialmanq + " I love crazy!")
        sc.game(readv, chracterquote + " All my life has been a series of doors in my face \nAnd then suddenly I bump into you")
        sc.game(readv, tutorialmanq + " I was thinking the same thing! 'Cause like \nI've been searching my whole life to find my own place \nAnd maybe it's the party talking or the chocolate fondue")
        sc.game(readv, chracterquote + " Can I say something crazy? \n" + chracterquote + " Will you marry me?")
        sc.game(readv, tutorialmanq + " Can I say something even crazier? \n" + tutorialmanq + " Yes!")
        sc.game(readv, "You have married with " + tutorialman + " so failed at saving " + neighbor + " and your dad.")
        failscreen2()
    else:
        sc.game(readv, tutorialmanq + " I assume you don't have any question. Now go and save " + neighbor + " and your father!")
        sc.game(readv, "You headed back to your house to prepare the dungeon trip \n")
        startingweapon()
    

def startingweapon():
    global stagesave
    stagesave=1.5
    ssg = open('ProSave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    sc.game(readv, "You can now choose your weapon")
    sc.game(readv, "Which weapon do you want to use? \n1)Carotte \n2)Céleri \n3)Concombre ")
    weaponchoice=input("")
    global weapon
    if weaponchoice=='1' or weaponchoice=='Carotte' or weaponchoice=='carotte':
        weapon='Carotte'
    elif weaponchoice=='2' or weaponchoice=='Celeri' or weaponchoice=='celeri':
        weapon='Céleri'
    elif weaponchoice=='3' or weaponchoice=='Concombre' or weaponchoice=='concombre':
        weapon='Concombre'
    elif weaponchoice=='god':
        weapon='Rods from God'
    elif weaponchoice=='24':
        weapon='Avocado Guacamole'
    else:
        sc.game(readv, "You have not chosen any weapon")
        sc.game(readv, "You are going to use a Potato as your weapon")
        one()
    sc.game(readv, "You have chosen " + weapon)
    wp = open('Informations/a' + username + 'wp.txt', 'w')
    wp.write(str(weapon))
    wp.close()
    print()
    startingdamage()

def startingdamage():
    global damage
    if weapon=='Carotte':
        damage=2
    if weapon=='Céleri':
        damage=3
    if weapon=='Concombre':
        damage=2
    if weapon=='Rods from God':
        damage=999999
    if weapon=='Avocado Guacamole':
        damage=32
    dam = open('Informations/a' + username + 'dg.txt', 'w')
    dam.write(str(damage))
    dam.close()
    startingattS()

def startingattS():
    global attS
    if weapon=='Carotte':
        attS=3
    if weapon=='Céleri':
        attS=1
    if weapon=='Concombre':
        attS=2
    if weapon=='Rods from God':
        attS=999999
    if weapon=='Avocado Guacamole':
        attS=100
    AS = open('Informations/a' + username + 'as.txt', 'w')
    AS.write(str(attS))
    AS.close()
    one()

def one():
    global stagesave
    stagesave=2
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    winsound.PlaySound(onemusic, winsound.SND_ASYNC + winsound.SND_LOOP)
    sc.game(readv, 'You come across a path, it splits at the end.')
    sc.game(readv, "Which path do you want to take? \n1)Left path \n2)Right path")
    choice=input("")
    checkone(choice)

def checkone(choice):
    if choice=='1':
        sc.game(readv, 'You have chosen the correct path')
        print()
        two()
    elif choice=='2':
        sc.game(readv, "That was the wrong way")
        print()
        failscreen()
    else:
        sc.game(readv, 'You decide to not take a path, and you die due to random circumstances.')
        sc.game(readv, 'Take a path next time, or at least take the correct one.')
        failscreen2()































def two():
    global enemyhp
    global enemydamage
    global enemyattS
    global enemy
    global stagesave
    global hp
    global inventory
    if chracter=='1':
        hp=100
        inventory = ['Red Burgundy', 'White Burgundy']
    if chracter=='2':
        hp=80
        inventory = ['Red Burgundy', 'White Burgundy', "Burgundy's Terroris"]
    stagesave=3
    hhp = open('Informations/a' + username + 'hp.txt', 'w')
    hhp.write(str(hp))
    hhp.close()
    ivs.invsav(inventory, username)
    ivs.invsav(inventory, username)
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    winsound.PlaySound(twomusic, winsound.SND_ASYNC + winsound.SND_LOOP)
    enemyhp=5
    enemydamage=1
    enemyattS=2
    enemy='Troll'
    sc.game(readv, 'You have met a ' + enemy)
    sc.game(readv, enemy + " exhale smelly breath at you")
    sc.game(readv, "What do you want to do?\n1)Attack\n2)Run away\n3)Use an item in inventory")
    twochoicefirst = input("")
    if twochoicefirst=='1':
        battle()
    #RUN
    elif twochoicefirst=='2':
        runawaytroll = random.randint(0,2)
        if runawaytroll==0:
            sc.game(readv, "You successfully ran away from the " + enemy)
            twobeforethree()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            enemyattack()
    
    elif twochoicefirst=='3':
        itemselection()

    else:
        sc.game(readv, "You have not reacted fast enough")
        sc.die("...")
        sc.game(readv, "YOU DIED!")
        failscreen()

def tworepeat():
    sc.game(readv, "What do you want to do?")
    twochoicefirst = input("1)Attack\n2)Run away\n3)use item in inventory \n")
    if twochoicefirst=='1':
        battle()
    #RUN
    elif twochoicefirst=='2':
        runawaytroll = random.randint(0,2)
        if runawaytroll==0:
            sc.game(readv, "You successfully ran away from the " + enemy)
            twobeforethree()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy + "'s smelly breath")
            enemyattack()
    
    elif twochoicefirst=='3':
        itemselection()

    else:
        sc.game(readv, "You have not reacted fast enough")
        sc.die("...")
        sc.game(readv, "YOU DIED!")
        failscreen()






















#ITEM
def itemselection():
    sc.game(readv, "These are the item(s) you have in your inventory, which item do you want to use?\n1: Cancel")
    loopCount = 2
    for itemNumber in inventory:
        loopCount = str(loopCount)
        sc.game(readv, loopCount + ': ' + itemNumber)
        loopCount = int(loopCount)
        loopCount+=1
    playerNumberChoice = int(input(""))
    playerItemChoice = inventory[playerNumberChoice-2]
    if playerNumberChoice == 1:
            sc.game(readv, "You hesitated and forgot to attack")
            enemyattack()
    elif playerItemChoice in inventory:
        if playerItemChoice == "White Burgundy":
            whiteB()
        elif playerItemChoice == "Burgundys Terroris":
            otherB()
        elif playerItemChoice == "Red Burgundy":
            redB()
    else:
        sc.game(readv, "You don't have " + playerItemChoice + " in your inventory")
        sc.game(readv, "You got confused and started eating a rock")
        sc.game(readv, "nom nom nom")
        rockeating = random.randint(0, 1)
        if rockeating==0:
            hp = hp + 5
            sc.game(readv, "That rock was poo of angel")
            sc.game(readv, "You have healed 5 HP")
            enemyattack()
        else:
            hp = hp - 5
            sc.game(readv, "That rock was poo of demon")
            winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
            sc.game(readv, "You have lost 5 HP")
            enemyattack()


def redB():
    global hp
    global inventory
    global partyhp
    if stagesave<=4 or neighbor=='Died':
        hp = hp + redb
        sc.game(readv, "You drunk the Red Burgundy \n")
    if stagesave>=5 and neighbor!='Died':
        redbb = redb/2
        hp = hp + redbb
        partyhp = partyhp + redbb
        sc.game(readv, "You shared the Red Burgundy with " + neighbor + "\n")
    inventory.remove('Red Burgundy')
    enemyattack()
def whiteB():
    global enemyhp
    global hp
    global inventory
    whitebdrink = random.randint(0,1)
    if whitebdrink==0:
        enemyhp = enemyhp - poison
        sc.game(readv, "You threw the White Burgundy and poisened the enemy")
        sc.game(readv, "The " + enemy + " lost 20 HP")
        inventory.remove('White Burgundy')
        enemyattack()
    else:
        hp = hp - poison
        sc.game(readv, "The White Burgundy poisoned you!")
        winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
        sc.game(readv, "You have lost 20 HP")
        inventory.remove('White Burgundy')
        enemyattack()
def otherB():
    global damage
    global inventory
    damage = damage + damageincrease
    inventory.remove("Burgundy's Terroris")
    sc.game(readv, "You have used Burgundy's Terroris \n")
    enemyattack()


def enemyattack():
    global attSE
    global hp
    global partyhp
    global enemyhp
    if stagesave<=4 or neighbor=='Died':
        winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
        sc.game(readv, enemy + " has attacked you")
        hp = hp - enemydamage
        hp = float(hp)
        if hp<=0:
            sc.game(readv, "The " + enemy + " has finally killed you \n")
            failscreen()
        sc.game(readv, "Enemy HP: " + str(enemyhp) + "\nYour HP: " + str(hp))
        enemyhp = float(enemyhp)
        hp = float(hp)
        print()
        itembattlestage()
    if stagesave>=5 and neighbor!='Died':
        winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
        sc.game(readv, enemy + " have attacked you and " + neighbor)
        hp = hp - enemydamage
        partyhp = partyhp - enemydamage
        hp = float(hp)
        partyhp = float(partyhp)
        if hp<=0:
            sc.game(readv, "The " + enemy + " has finally killed you \n")
            failscreen()
        if partyhp<=0:
            sc.game(readv, "The " + enemy + " has finally killed " + neighbor + "\n")
            neighbordie()

    if neighbor!="Died":
        sc.game(readv, "Enemy HP: " + str(enemyhp) + "\nYour HP: " + str(hp) + "\n" + neighbor + " HP: " + str(partyhp))
        print()
    if neighbor=="Died":
        sc.game(readv, "Enemy HP: " + str(enemyhp) + "\nYour HP: " + str(hp))
        print()
        hp = float(hp)
        partyhp = float(partyhp)
        enemyhp = float(enemyhp)
    itembattlestage()

def battle():
    global attSE
    global attS
    global enemyhp
    global hp
    global partyhp
    global enemyattS
    global endtime
    global errorsoonser
    global errortype
    if stagesave<=4 or neighbor=='Died':
        if attS==enemyattS:
            attSE = 0
            attSE = random.randint(0,1)
            #1 is for you 2 is for troll
        elif attS>=enemyattS or attSE==1:
            sc.game(readv, "You have attacked the " + enemy + " with your " + weapon)
            enemyhp = enemyhp - damage
            enemyhp = float(enemyhp)
            if enemyhp<=0:
                sc.game(readv, "You have slayed the " + enemy + " nice job \n")
                afterbattle()
            winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
            sc.game(readv, enemy + " have attacked you")
            hp = hp - enemydamage
            hp = float(hp)
            if hp<=0:
                sc.game(readv, "The " + enemy + " has finally killed you \n")
                failscreen()
            sc.game(readv, "Enemy HP: " + str(enemyhp) + "\nYour HP: " + str(hp))
            enemyhp = float(enemyhp)
            hp = float(hp)
            print()
        elif attS<=enemyattS or attSE==0:
            winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
            sc.game(readv, enemy + " has attacked you")
            hp = hp - enemydamage
            hp = float(hp)
            if hp<=0:
                sc.game(readv, "The " + enemy + " has finally killed you \n")
                failscreen()
            sc.game(readv, "You have attacked the " + enemy + " with your " + weapon)
            enemyhp = enemyhp - damage
            enemyhp = float(enemyhp)
            if enemyhp<=0:
        
                sc.game(readv, "You have slayed the " + enemy + "\nNice job! \n")
                afterbattle()
            sc.game(readv, "Enemy HP: " + str(enemyhp) + "\nYour HP: " + str(hp))
            enemyhp = float(enemyhp)
            hp = float(hp)
            print()
        else:
            endtime = tom.time()
            errorsoonser = 1
            errortype = 'B'
            errorscreen()
        itembattlestage()
    if stagesave>=5 and neighbor!='Died':
        if attS==enemyattS:
            attSE = 0
            attSE = random.randint(0,1)
            #1 is for you 0 is for troll
        elif attS>=enemyattS or attSE==1:
            sc.game(readv, "You have attacked " + enemy + " with your " + weapon)
            sc.game(readv, neighbor + " have attacked with " + partyweapon)
            teamdamage = damage + partydamage
            teamdamage = float(teamdamage)
            enemyhp = enemyhp - teamdamage
            enemyhp = float(enemyhp)
            if enemyhp<=0:
                sc.game(readv, "You and " + neighbor + " have slayed the " + enemy + " nice job \n")
                afterbattle()
            winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
            sc.game(readv, enemy + " has attacked you and " + neighbor)
            hp = hp - enemydamage
            partyhp = partyhp - enemydamage
            hp = float(hp)
            partyhp = float(partyhp)
            if hp<=0:
                sc.game(readv, "The " + enemy + " has finally killed you \n")
                failscreen()
            if partyhp<=0:
                sc.game(readv, "The " + enemy + " has finally killed " + neighbor + "\n")
                neighbordie()
            sc.game(readv, "Enemy HP: " + str(enemyhp) + "\nYour HP: " + str(hp) + "\n" + neighbor + " HP: " + str(partyhp))
            enemyhp = float(enemyhp)
            hp = float(hp)
            partyhp = float(partyhp)
            print()
        elif attS<=enemyattS or attSE==0:
            winsound.PlaySound(winsound.Beep(600, 100), winsound.SND_ASYNC)
            sc.game(readv, enemy + " has attacked you and " + neighbor)
            hp = hp - enemydamage
            partyhp = partyhp - enemydamage
            hp = float(hp)
            partyhp = float(partyhp)
            if hp<=0:
                sc.game(readv, "The " + enemy + " has finally killed you \n")
                failscreen()
            if partyhp<=0:
                sc.game(readv, "The " + enemy + " has finally killed " + neighbor + "\n")
                neighbordie()
            sc.game(readv, "You have attacked " + enemy + " with your " + weapon)
            sc.game(readv, neighbor + " has attacked with " + partyweapon)
            teamdamage = damage + partydamage
            teamdamage = float(teamdamage)
            enemyhp = enemyhp - teamdamage
            enemyhp = float(enemyhp)
            if enemyhp<=0:
        
                sc.game(readv, "You and " + neighbor + " have slayed the " + enemy + " nice job \n")
                afterbattle()
    
            sc.game(readv, "Enemy HP: " + str(enemyhp) + "\nYour HP: " + str(hp) + "\n" + neighbor + "HP: " + str(partyhp))
            enemyhp = float(enemyhp)
            hp = float(hp)
            partyhp = float(partyhp)
            print()
        else:
            endtime = tom.time()
            errorsoonser = 2
            errortype = 'B'
            errorscreen()
        itembattlestage()
        

def neighbordie():
    global monsterk
    global neighbor
    sc.game(readv, neighborquote + " I am sorry, I hope you keep going to find your father")
    neighbor='Died'
    monsterk = enemy
    nb = open('Informations/a' + username + 'nb.txt', 'w')
    nb.write(neighbor)
    nb.close()
    mk = open('Informations/a' + username + 'mk.txt', 'w')
    mk.write(monsterk)
    mk.close()
    itembattlestage()

def twobeforethree():
    global damage
    global attS
    if weapon=='Carotte':
        attS=3
    if weapon=='Céleri':
        attS=1
    if weapon=='Concombre':
        attS=2
    if weapon=='Rods from God':
        attS=999999
    if weapon=='Avocado Guacamole':
        attS=100
    if weapon=='Carotte':
        damage=2
    if weapon=='Céleri':
        damage=3
    if weapon=='Concombre':
        damage=2
    if weapon=='Rods from God':
        damage=999999
    if weapon=='Avocado Guacamole':
        damage=32
    dam = open('Informations/a' + username + 'dg.txt', 'w')
    dam.write(str(damage))
    dam.close()
    AS = open('Informations/a' + username + 'as.txt', 'w')
    AS.write(str(attS))
    AS.close()
    three()

def three():
    global stagesave
    stagesave = 3.1
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    hhp = open('Informations/a' + username + 'hp.txt', 'w')
    hhp.write(str(hp))
    hhp.close()
    ivs.invsav(inventory, username)
    winsound.PlaySound(threemusic, winsound.SND_ASYNC + winsound.SND_LOOP)
    sc.game(readv, "You have found 3 types of chest")
    sc.game(readv, "The first one was a golden chest")
    sc.game(readv, "The second one was a silver chest")
    sc.game(readv, "The third one was a wooden chest")
    sc.game(readv, "Which chest do you want to open?")
    sc.game(readv, "If you don't select a chest it will automatically be dropped on into the lava")
    sc.game(readv, "1)Golden Chest\n2)Silver Chest\n3)Wooden Chest")
    chestchoice = input("")
    if chestchoice=='1':
        sc.game(readv, "You chose the golden chest")
        sc.game(readv, "You have opened golden chest")
        for x in goldenchest:
            inventory.append(x)
        sc.inv(readv, "Now you have these items in your inventory \n", inventory)
    elif chestchoice=='2':
        sc.game(readv, "You chose the silver chest")
        sc.game(readv, "You have opened silver chest")
        for x in silverchest:
            inventory.append(x)
        sc.game(readv, "Now you have these items in your inventory \n" + inventory)
    elif chestchoice=='3':
        sc.game(readv, "You chose the wooden chest")
        sc.game(readv, "You have opened wooden chest")
        for x in woodenchest:
            inventory.append(x)
        sc.game(readv, "Now you have these items in your inventory \n" + inventory)
    else:
        sc.game(readv, "Do you not want to open a chest?")
        sc.game(readv, "Ok, that's fine")
        print()

        four()
    sc.game(readv, "Items are added in your inventory")
    print()
    four()


def four():
    global stagesave
    global partydamage
    global partyhp
    global partyweapon
    global partyinventory
    stagesave=4
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    if neighbor=='Ahh Choux':
        partydamage=7
        partyhp=60
        partyweapon=''
        partyinventory=['a','b']
    if neighbor=='Biscotti Fontina':
        partydamage=6
        partyhp=70
        partyweapon=''
        partyinventory=['a','b']
    php = open('Informations/a' + username + 'php.txt', 'w')
    php.write(str(partyhp))
    php.close()
    hhp = open('Informations/a' + username + 'hp.txt', 'w')
    hhp.write(str(hp))
    hhp.close()
    ivs.invsav(inventory, username)
    winsound.PlaySound(fourmusic, winsound.SND_ASYNC + winsound.SND_LOOP)
    sc.game(readv, "You see a dark silhouette at the end of the path")
    sc.game(readv, "As you get closer you are able to make out more of their defining features")
    sc.game(readv, "When you get really close you realise who the lost person is")
    sc.game(readv, "You see your neighbor, " + neighbor)
    sc.game(readv, chracterquote + neighbor + "! Are you okay?")
    sc.game(readv, neighborquote + " I'm fine. A monster took your father down the other way.")
    sc.game(readv, chracterquote + " You wait here. Let me go and find him.")
    sc.game(readv, neighborquote + " Let me join you.")
    sc.game(readv, "1)Okay. Let's go. \n2)I am sorry the dungeon is too dangerous, just go back to the town. \n")
    neighborparty = input("")
    if neighborparty=='1':
        sc.game(readv, chracterquote + " Okay. Let's go.")
        sc.game(readv, neighbor + " joined your party!")
        sc.game(readv, neighbor + " was too exited and accidently tripped over you")

        failscreen()
    if neighborparty=='2':
        sc.game(readv, chracterquote + " I am sorry the dungeon is too dangerous, just go back to the town.")
        sc.game(readv, neighborquote + " I don't care I'm joining your party!")
        sc.game(readv, neighbor + " joined your party and you started heading to next the room.")
    print()
    five()


def five():
    global enemy
    global stagesave
    global enemydamage
    global enemyhp
    global enemyattS
    enemy='Homme de Pierre'
    enemyhp = 7
    enemyattS = 6
    enemydamage = 3
    stagesave=5
    hhp = open('Informations/a' + username + 'hp.txt', 'w')
    hhp.write(str(hp))
    hhp.close()
    ivs.invsav(inventory, username)
    php = open('Informations/a' + username + 'php.txt', 'w')
    php.write(str(partyhp))
    php.close()
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    enemydamage=3
    enemyhp=7
    enemyattS=6
    winsound.PlaySound(fivemusic, winsound.SND_ASYNC + winsound.SND_LOOP)
    sc.game(readv, "As you are walking down the path you have met a giant Homme de Pierre")
    sc.game(readv, chracterquote + " He is really tall, he looks taller than Mr.Oasty.")
    sc.game(readv, neighborquote + " Yeah isn't Mr.Oasty 7 feet tall?")
    sc.game(readv, neighborquote + " He looks like he is sleeping though")
    sc.game(readv, neighborquote + " We have two choices \n1)Go to the entrance quitly \n2)Dance infront of the Homme de Pierre")
    input("")
    sc.game(readv, "The Homme de Pierre spotted you")
    sc.game(readv, neighborquote + " Oh no")
    sc.game(readv, chracterquote + " prepare for a battle " + neighbor)
    sc.game(readv, neighborquote + " Ok!")
    sc.game(readv, enemy + " tries to attack you and " + neighbor)
    sc.game(readv, "What do you want to do?")
    fivechoice = input("1)Attack\n2)Run away\n3)use item in inventory\n")
    if fivechoice=='1':
        battle()
    if fivechoice=='2':
        runawaygolem = random.randint(0,4)
        if runawaygolem==3:
            sc.game(readv, "You have successfully run away from the " + enemy)
            fivebeforesix()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            failscreen()
    if fivechoice=='3':
        itemselection()
    

def fiverepeat():
    sc.game(readv, "What do you want to do?")
    fivechoice = input("1)Attack\n2)Run away\n3)use item in inventory\n")
    if fivechoice=='1':
        battle()
    if fivechoice=='2':
        runawaygolem = random.randint(0,4)
        if runawaygolem==3:
            sc.game(readv, "You have successfully run away from the " + enemy)
            fivebeforesix()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            failscreen()
    if fivechoice=='3':
        itemselection()

def fivebeforesix():
    global damage
    global attS
    if weapon=='Carotte':
        attS=3
    if weapon=='Céleri':
        attS=1
    if weapon=='Concombre':
        attS=2
    if weapon=='Rods from God':
        attS=999999
    if weapon=='Avocado Guacamole':
        attS=100
    if weapon=='Carotte':
        damage=2
    if weapon=='Céleri':
        damage=3
    if weapon=='Concombre':
        damage=2
    if weapon=='Rods from God':
        damage=999999
    if weapon=='Avocado Guacamole':
        damage=32
    dam = open('Informations/a' + username + 'dg.txt', 'w')
    dam.write(str(damage))
    dam.close()
    AS = open('Informations/a' + username + 'as.txt', 'w')
    AS.write(str(attS))
    AS.close()
    six()

def six():
    global stagesave
    stagesave=6
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    hhp = open('Informations/a' + username + 'hp.txt', 'w')
    hhp.write(str(hp))
    hhp.close()
    ivs.invsav(inventory, username)
    php = open('Informations/a' + username + 'php.txt', 'w')
    php.write(str(partyhp))
    php.close()
    winsound.PlaySound(sixmusic, winsound.SND_ASYNC + winsound.SND_LOOP)
    sc.game(readv, "You come to the end of the road")
    sc.game(readv, "Which way do you want to go?")
    road4=int(input("1)Left path \n2)Middle path \n3)Right path\n"))
    rd4 = open('Informations/a' + username + 'rd.txt', 'w')
    rd4.write(str(road4))
    rd4.close()
    sixcheck(road4)
    
def sixcheck(road4):
    global stagesave
    global enemy
    global weaponab
    global enemyhp
    global enemyattS
    global enemydamage
    if road4==1 or stagesave==6.1:
        sc.game(readv, "You chose the left path")
        stagesave=6.1
        ssg = open('Prosave/a' + username + 'ps.txt', 'w')
        ssg.write(str(stagesave))
        ssg.close()
        enemy='Fantôme'
        enemyhp = 8
        enemyattS = 7
        enemydamage = 4
        weaponab='Choux de Bruxelles'
        sc.game(readv, "You see a " + enemy + " hovering beside a glowing " + weaponab)
        if neighbor!='Died':
            sc.game(readv, neighborquote + " Do you want to get close to that?")
        if neighbor=='Died':
            sc.game(readv, chracterquote + " Should I get close to that?")
        sc.game(readv, "1)Yes I want to get close to him and look at it. \n2)No that is too dangerous I want to go the other way")
        sixlefta = input("")
        if sixlefta=='2':
            sc.game(readv, "You went back to fork of the road")
            six()
        if sixlefta=='1':
            sc.game(readv, "The " + enemy + " noticed you, he starts to stares at you")
    
            sc.game(readv, "You and the " + enemy + " started fighting")
            sixleft()
        else:
            sc.game(readv, "It was too late to choose something different to do")
    
            sc.game(readv, "He is coming towards you")
            sixleft()
    if road4==2 or stagesave==6.2:
        sc.game(readv, "You chose the middle path")
        stagesave=6.2
        ssg = open('Prosave/a' + username + 'ps.txt', 'w')
        ssg.write(str(stagesave))
        ssg.close()
        enemy='Faucheuse'
        enemyhp = 12
        enemyattS = 8
        enemydamage = 6
        weaponab='Betterave'
        sc.game(readv, "You see a " + enemy + " standing beside a glowing " + weaponab)
        if neighbor!='Died':
            sc.game(readv, neighborquote + " That look's horrify, can we go back?")
        if neighbor=='Died':
            sc.game(readv, chracterquote + " That guy look's scary, should I go back?")
        sc.game(readv, "1)Go back and choose different path \n2)Let's just go through")
        sixmida = input("")
        if sixmida=='1':
            sc.game(readv, "You went back to fork in the road")
            six()
        if sixmida=='2':
            sc.game(readv, "He found you and he teleported to your behind")
            sixmiddle()
        else:
            sc.game(readv, "It was too late to choose to do different thing")
            sc.game(readv, "He is walking towards you slowly")
            sc.game(readv, "He took out his enormous sickle and he try to slaughter you")
            sixmiddle()
    if road4==3 or stagesave==6.4:
        sc.game(readv, "You chose the right path")
        stagesave=6.4
        ssg = open('Prosave/a' + username + 'ps.txt', 'w')
        ssg.write(str(stagesave))
        ssg.close()
        weaponab='Le Maïs Sucré'
        enemy='Monstre Gluant'
        enemyhp = 10
        enemyattS = 9
        enemydamage = 9
        sc.game(readv, "You see a " + enemy + " sleeping beside a glowing " + weaponab)
        if neighbor!='Died':
            sc.game(readv, neighborquote + " Oh, that guy look's cute, wanna get closer?")
        if neighbor=='Died':
            sc.game(readv, chracterquote + " ummm that look's quite slimy, should i get closer?")
        sc.game(readv, "1)Go back and choose different path \n2)Let's get closer and play with him.")
        sixmida = input("")
        if sixmida=='1':
            sc.game(readv, "You went back to fork of the road")
            six()
        if sixmida=='2':
            sc.game(readv, "He smiles at you and throw's acid at you")
            sixright()
        else:
            sc.game(readv, "It was too late to choose to do different thing")
            sc.game(readv, "He threw acid at you")
            sixright()


def sixleft():
    sc.game(readv, "What do you want to do?")
    userchoice = input("1)Attack\n2)Run away\n3)use item in inventory\n")
    if userchoice=='1':
        battle()
    #RUN
    elif userchoice=='2':
        runawaytroll = random.randint(0,4)
        if runawaytroll==0:
            sc.game(readv, "You successfully ran away from the " + enemy)
            afterbattle()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            enemyattack()
    
    elif userchoice=='3':
        itemselection()

    else:
        sc.game(readv, "You havn't reacted fast enough")
        sc.die("...")
        sc.game(readv, "YOU DIED!")
        failscreen()

    

def sixmiddle():
    sc.game(readv, "What do you want to do?")
    userchoice = input("1)Attack\n2)Run away\n3)use item in inventory\n")
    if userchoice=='1':
        battle()
    #RUN
    elif userchoice=='2':
        runawaytroll = random.randint(0,4)
        if runawaytroll==0:
            sc.game(readv, "You successfully ran away from the " + enemy)
            afterbattle()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            enemyattack()
    
    elif userchoice=='3':
        itemselection()

    else:
        sc.game(readv, "You havn't reacted fast enough")
        sc.die("...")
        sc.game(readv, "YOU DIED!")
        failscreen()
    

def sixright():
    sc.game(readv, "What do you want to do?")
    userchoice = input("1)Attack\n2)Run away\n3)use item in inventory\n")
    if userchoice=='1':
        battle()
    #RUN
    elif userchoice=='2':
        runawaytroll = random.randint(0,4)
        if runawaytroll==0:
            sc.game(readv, "You successfully ran away from the " + enemy)
            afterbattle()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            enemyattack()
    
    elif userchoice=='3':
        itemselection()

    else:
        sc.game(readv, "You havn't reacted fast enough")
        sc.die("...")
        sc.game(readv, "YOU DIED!")
        failscreen()

def sixbeforeseven():
    global weapon
    global damage
    global attS
    weapon = weaponab
    if weapon=='Carotte':
        attS=3
    if weapon=='Céleri':
        attS=1
    if weapon=='Concombre':
        attS=2
    if weapon=='Rods from God':
        attS=999999
    if weapon=='Avocado Guacamole':
        attS=100
    if weapon=='Carotte':
        damage=2
    if weapon=='Céleri':
        damage=3
    if weapon=='Concombre':
        damage=2
    if weapon=='Rods from God':
        damage=999999
    if weapon=='Avocado Guacamole':
        damage=32
    if stagesave==6.1:
        weapon = 'Choux de Bruxelles'
        attS=4
        damage=4
    if stagesave==6.2:
        weapon = 'Betterave'
        attS=4
        damage=6
    if stagesave==6.4:
        weapon = 'Le Maïs Sucré'
        attS=6
        damage=7
    dam = open('Informations/a' + username + 'dg.txt', 'w')
    dam.write(str(damage))
    dam.close()
    AS = open('Informations/a' + username + 'as.txt', 'w')
    AS.write(str(attS))
    AS.close()
    wp = open('Informations/a' + username + 'wp.txt', 'w')
    wp.write(str(weapon))
    wp.close()
    seven()

def seven():
    global stagesave
    global enemy
    global enemydamage
    global enemyhp
    global enemyattS
    enemy='Baguette Cantel'
    enemyhp=30
    enemydamage=4
    enemyattS=100
    stagesave=7
    winsound.PlaySound(sevenmusic, winsound.SND_ASYNC + winsound.SND_LOOP)
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    hhp = open('Informations/a' + username + 'hp.txt', 'w')
    hhp.write(str(hp))
    hhp.close()
    ivs.invsav(inventory, username)
    php = open('Informations/a' + username + 'php.txt', 'w')
    php.write(str(partyhp))
    php.close()
    if neighbor=='Died':
        sc.game(readv, chracterquote + " Dad?")
        sc.game(readv, fatherq + " Hello, " + chractername)
        print()
    if neighbor!='Died':
        sc.game(readv, chracterquote + " There is my father, help me rescue him " + neighbor)
        sc.game(readv, neighborquote + " Ok let's do it")
        sc.game(readv, fatherq + " Hello, " + chractername)
    sc.game(readv, chracterquote + " Dad? What the flop are you doing down here?")
    sc.game(readv, fatherq + chractername + " I have been unwell lately")
    sc.game(readv, fatherq + " I needed to come down here to stop me from killing the townsfolk.")  
    sc.game(readv, chracterquote + " What the flop do you mean?")
    sc.game(readv, fatherq + " I have avoided telling you this for years")
    sc.game(readv, chracterquote + " What the flop is it dad?")
    sc.game(readv, fatherq + " I have been infected with an artificial virus")
    sc.game(readv, chracterquote + " Im confused")
    sc.game(readv, fatherq + " I knew you would be, that is why I didn't tell you until now")
    sc.game(readv, chracterquote + " I understand, you didn't want to scare me")
    sc.game(readv, fatherq + " Don't worry its very safe when it's under control. They have done lots of test's on my body")
    sc.game(readv, chracterquote + " Who is they exactly?")
    sc.game(readv, fatherq + " They are from the endless darkness full of inferno to deliver eternal chaos.")
    sc.game(readv, chracterquote + " Does that mean that they are demons from hell?")
    sc.game(readv, fatherq + " Yes.")
    sc.game(readv, chracterquote + " You could've just said demons instead of that.")
    sc.game(readv, fatherq + " Yeah, sorry. It sounds cool though.")
    sc.game(readv, chracterquote + " Anyway, when did you get that?")
    sc.game(readv, fatherq + " 15 years ago approximately. Do you remember I read you a story of a brave hero who went to the dungeon to save the world?")
    sc.game(readv, chracterquote + " Yes.")
    sc.game(readv, fatherq + " That brave hero is me.")
    sc.game(readv, chracterquote + " Is that why you described that hero as handsome and sexy?")
    sc.game(readv, fatherq + " Well, I was handsome and sexy 15 years ago.")
    sc.game(readv, chracterquote + " Ok, dad I believe you")
    sc.game(readv, fatherq + " anyway after slaying the boss, I fainted in the dungeon.")
    sc.game(readv, fatherq + " They did not miss the chance. They injected me with a drug that made me feel numb.")
    sc.game(readv, fatherq + " and did lots of tests.")
    sc.game(readv, fatherq + " After that, I turn in to a monster when my stress gets high.")
    if neighbor=='Died':
        sc.game(readv, chracterquote + " Is there any way to heal you?")
    if neighbor!='Died':
        sc.game(readv, neighborquote + " Is there any way to heal you?")
    sc.game(readv, fatherq + " No, but you can turn me in to human again, Only way to do that is to fight against me.")
    sc.game(readv, chracterquote + " WHAT!")
    if neighbor!='Died':
        sc.game(readv, neighborquote + " WHAT!")
    sc.game(readv, fatherq + " You need to stop my heartbeat when I am in monster form then I can turn back into a human again.")
    sc.game(readv, chracterquote + " Dad....")
    sc.game(readv, fatherq + " Don't worry, " + chractername + " I am not going to trun in to a monster unless I get angry.")
    sc.game(readv, fatherq + " How was your life " + chractername + "?")
    sc.game(readv, chracterquote + " It was very good, I played a lot of games.")
    sc.game(readv, fatherq + " What game did you play?")
    sc.game(readv, chracterquote + " Fortnite")
    sc.game(readv, fatherq + " awwww I....am...sorry...I...can't..handle..the....ang..er...")
    sc.game(readv, fatherq + ' Rawr >w<')
    seventwo()

def seventwo():
    global stagesave
    global enemy
    global enemydamage
    global enemyhp
    global enemyattS
    enemy='Baguette Cantel'
    enemyhp=30
    enemydamage=4
    enemyattS=100
    stagesave=7.1
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    hhp = open('Informations/a' + username + 'hp.txt', 'w')
    hhp.write(str(hp))
    hhp.close()
    ivs.invsav(inventory, username)
    php = open('Informations/a' + username + 'php.txt', 'w')
    php.write(str(partyhp))
    php.close()
    if neighbor!='Died':
        sc.game(readv, chracterquote + neighbor + " We need to do this, we need to stop him \n")
    if neighbor=='Died':
        sc.game(readv, chracterquote + " I need to do this. I need to stop his heart to bring back my dad in to human again.")
    sc.game(readv, "What do you want to do?")
    userchoice = input("1)Attack\n2)Run away\n3)use item in inventory\n")
    if userchoice=='1':
        battle()
    #RUN
    elif userchoice=='2':
        runawaytroll = random.randint(0,4)
        if runawaytroll==0:
            sc.game(readv, "You successfully ran away from the " + enemy)
            afterbattle()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            enemyattack()
    
    elif userchoice=='3':
        itemselection()

    else:
        sc.game(readv, "You havn't reacted fast enough")
        sc.die("...")
        sc.game(readv, "YOU DIED!")
        failscreen()
    battle()

def sevenrepeat():
    sc.game(readv, "What do you want to do?")
    userchoice = input("1)Attack\n2)Run away\n3)use item in inventory\n")
    if userchoice=='1':
        battle()
    #RUN
    elif userchoice=='2':
        runawaytroll = random.randint(0,4)
        if runawaytroll==0:
            sc.game(readv, "You successfully ran away from the " + enemy)
            afterbattle()
        else:
            sc.game(readv, "You have failed escaping from the " + enemy)
            enemyattack()
    
    elif userchoice=='3':
        itemselection()

    else:
        sc.game(readv, "You havn't reacted fast enough")
        sc.die("...")
        sc.game(readv, "YOU DIED!")
        failscreen()
    
def sevenbeforelast():
    global stagesave
    global endtime
    global errorsoonser
    global errortype
    global dadd
    stagesave=8
    ssg = open('Prosave/a' + username + 'ps.txt', 'w')
    ssg.write(str(stagesave))
    ssg.close()
    if neighbor=="Died":
        sc.game(readv, chracterquote + " I saved him but he will keep on chaning when he gets angry....should I finish him here?")
    if neighbor!='Died':
        sc.game(readv, neighborquote + " We saved him now but he will keep changing into a monster when ever he gets stressed, we need to end this tragedy here " + chractername + ".")
    sc.game(readv, "1)Kill your father \n2)Make him faint")
    patha = input("")
    if patha=='1' and neighbor=='Died':
        dadd = 'Died'
        sc.game(readv, chracterquote + " Yes, that's right, I need to finish him.")
        sc.game(readv, chracterquote + " Otherwise, he could kill other people.")
        sc.game(readv, chracterquote + " I'm sorry dad, I love you....")
        winsound.PlaySound(knifestab, winsound.SND_ASYNC)
        sc.game(readv, "You went back home by yourself.")
        endc()
    if patha=='2' and neighbor=='Died':
        sc.game(readv, chracterquote + " I can't kill him even though I know that he might hurt someone else potentially.")
        sc.game(readv, chracterquote + " I don't wanna lost 2 close ones in a single day.")
        sc.game(readv, "You fainted him and went back to home.")
    elif patha=='1':
        dadd = 'Died'
        sc.game(readv, chracterquote + " Ok, let's....kill him.")
        sc.game(readv, neighborquote + chractername + " Look the other way, cover your ears. I'll do it.")
        sc.game(readv, chracterquote + " Thank you " + neighbor + ".")
        winsound.PlaySound(knifestab, winsound.SND_ASYNC)
        sc.game(readv, "You and " + neighbor + " went back home.\n")
        enda()
    elif patha=='2':
        sc.game(readv, chracterquote + " I'm sorry, but he is my father")
        sc.game(readv, chracterquote + " I will stop him when he turns into a monster")
        sc.game(readv, chracterquote + " I will give up my life to stop him if it is necessary. \n")
        sc.game(readv, neighborquote + " Ok, I'm sorry " + chractername + " I will help you when he turns in to a monster.")
        sc.game(readv, "You and " + neighbor + " went back home with your dad \n")
        endb()
    else:
        endtime = tom.time()
        errorsoonser = 3
        errortype = 'A'
        errorscreen()

def enda():
    winsound.PlaySound(endcredit2, winsound.SND_ASYNC)
    sc.game(readv, "10 years later")
    sc.game(readv, chracterquote + " Me and my wife " + neighbor + " are still living in Pont-Évêque.")
    sc.game(readv, chracterquote + " I still regret my decision to kill my father")
    sc.game(readv, chracterquote + " I could not sleep well after that happen.")
    sc.game(readv, chracterquote + " Me and " + neighbor + " closed the dungeon after killing my father")
    sc.game(readv, chracterquote + " We tried to bring his body with us but the dungeon was collapsing quickly.")
    sc.game(readv, chracterquote + " His corpse is still rotting down there")
    sc.game(readv, chracterquote + " I'm sorry dad...")
    sc.game(readv, "Your mum left the town after you told her that you killed your dad.")
    sc.game(readv, "Later on, you found out that there was a cure for your dad.")
    sc.game(readv, neighbor + " and you will regret the decision you made in the dugeon forever.")
    endingscreen()

def endb():
    winsound.PlaySound(endcredit, winsound.SND_ASYNC)
    sc.game(readv, "10 years later")
    sc.game(readv, chracterquote + " Me and my wife " + neighbor + " are still living in Pont-Évêque with my father Baguette living next door to us.")
    sc.game(readv, chracterquote + " I have always worried incase my father turns in to a monster again.")
    sc.game(readv, chracterquote + " But that never happened.")
    sc.game(readv, chracterquote + " Me and " + neighbor + " closed the dungeon 10 years ago and we are still protecting our home town Pont-Évêque together.")
    sc.game(readv, chracterquote + " We still don't know how to heal my fahter but we are happy enough.")
    sc.game(readv, "Your father never turned in to a monster after the first fight.")
    sc.game(readv, "You, " + neighbor + " and your parents lived happy life together")
    endingscreen()

def endc():
    if chracter==1:
        neighborname = 'Ahh Choux'
    if chracter==2:
        neighborname = 'Biscotti Fontina'
    winsound.PlaySound(endcredit2, winsound.SND_ASYNC)
    sc.game(readv, "10 years later")
    sc.game(readv, chracterquote + " I am still living in Pont-Évêque.")
    sc.game(readv, chracterquote + " I gave up being a hero of my town")
    sc.game(readv, chracterquote + " That mysterious dungeon took all my close ones")
    sc.game(readv, chracterquote + " That dungeon took my dad and " + neighborname + " away and my mum left me when she heard no one survived except me.")
    sc.game(readv, chracterquote + " My beloved " + neighborname + " died from " + monsterk + ".")
    sc.game(readv, chracterquote + " and I killed my father.")
    sc.game(readv, chracterquote + " I regret my decision of killing my father")
    sc.game(readv, chracterquote + " Well maybe I did it because, I was younger back then")
    sc.game(readv, chracterquote + " I closed the dungeon after killing my father")
    sc.game(readv, chracterquote + " I have tried to bring their bodies but dungeon was falling apart....")
    sc.game(readv, chracterquote + " Their corpse is still rotting down there")
    sc.game(readv, chracterquote + " i'm sorry dad...")
    sc.game(readv, chracterquote + " i'm sorry " + neighborname + ".....")
    sc.game(readv, "Later on, you found out that there was a cure for your dad.")
    sc.game(readv, "You have attempted suicide multiple times but all of attempts were not successful")
    sc.game(readv, "You regret your decisions and currently hate your life")
    endingscreen()

def endd():
    if chracter==1:
        neighborname = 'Ahh Choux'
        neighborgender = 'her'
    if chracter==2:
        neighborname = 'Biscotti Fontina'
        neighborgender = 'his'
    winsound.PlaySound(endcredit2, winsound.SND_ASYNC)
    sc.game(readv, "10 years later")
    sc.game(readv, chracterquote + " I am still living in Pont-Évêque with my father Baguette")
    sc.game(readv, chracterquote + " I have always worried incase my father turns in to a monster again.")
    sc.game(readv, chracterquote + " But that never happened.")
    sc.game(readv, chracterquote + " I closed the dungeon 10 years ago and I am still protecting my home town Pont-Évêque.")
    sc.game(readv, chracterquote + " I still don't know how to heal my father.")
    sc.game(readv, chracterquote + " And I never forgotten " + neighborname + " as long as I lived")
    sc.game(readv, chracterquote + " I have tried to bring " + neighborgender + " body but dungeon was falling apart....")
    sc.game(readv, chracterquote + " i'm sorry " + neighborname + "....")
    sc.game(readv, chracterquote + " It's bit late but I still love you " + neighborname + ".")
    sc.game(readv, "You threw a mysterious box in to the bin")
    sc.game(readv, "You saved your dad but the fact that " + neighborname + " died will make you regret until you die")
    endingscreen()


def itembattlestage():
    global errorsoonser
    global errortype
    global endtime
    """try:"""
    if stagesave==3:
        tworepeat()
    if stagesave==5:
        fiverepeat()
    if stagesave==6.1:
        sixleft()
    if stagesave==6.2:
        sixmiddle()
    if stagesave==6.4:
        sixright()
    if stagesave==7.1:
        sevenrepeat()
    else:
        errorsoonser = 18
        errortype = 'C'
        endtime = tom.time()
        errorscreen()
    """except:
        errorsoonser = 16
        errortype = 'C'
        endtime = tom.time()
        errorscreen()"""

def afterbattle():
    global errorsoonser
    global errortype
    global endtime
    """try:"""
    if stagesave==3:
        twobeforethree()
    if stagesave==5:
        fivebeforesix()
    if 7>=stagesave>=6:
        sixbeforeseven()
    else:
        errorsoonser = 17
        errortype = 'C'
        endtime = tom.time()
        errorscreen()
    """except:
        errorsoonser = 15
        errortype = 'C'
        endtime = tom.time()
        errorscreen()"""

def failscreen():
    global errorsoonser
    global errortype
    global endtime
    global road4
    road4 = 0
    diedie=None
    winsound.PlaySound(None, winsound.SND_ASYNC)
    winsound.PlaySound(failfail, winsound.SND_ASYNC)
    if os.path.exists('Others/a' + username + 'fn.txt') == False:
        failnum = open('Others/a' + username + 'fn.txt', 'w')
        startingnum = '1'
        failnum.write(startingnum)
        failnum.close()
    if os.path.exists('Others/a' + username + 'fn.txt') == True:
        failnum = open('Others/a' + username + 'fn.txt', 'r+')
        failnumbers = failnum.read()
        failnumbers = float(failnumbers)
        failnumbers += 1
        failnumbers = str(failnumbers)
        failnum.write(failnumbers)
        failnum.close()
    sc.game(readv, "You have died.")
    sc.game(readv, "Do you want to restart from the previous save?")
    sc.game(readv, "1)Yes, I want to restart from the previous save. \n2)No, I want to restart from the beginning. \n3)No, I want to stop playing.")
    restart1=input("")
    if restart1=='2':
        chracterselect()
    if restart1=='1':
        diedie=False
    if restart1=='3':
        diedie=True
    else:
        while restart1!='1' and restart1!='2' and restart1!='3':
            sc.game(readv, "Choose a valid answer")
    
            sc.game(readv, "Do you want to restart from the previous save?")
            sc.game(readv, "1)Yes, I want to restart it from previous save. \n2)No, I want to restart it from beginning. \n3)No, I want to stop playing.")
            restart1 = input("")
            if restart1=='2':
                chracterselect()
            elif restart1=='1':
                diedie=False
            elif restart1=='3':
                diedie=True
    if diedie==False:
        direction()
    if diedie==True:
        exit()
    else:
        errorsoonser = 14
        errortype = 'A'
        endtime = tom.time()
        errorscreen()


def failscreen2():
    global endtime
    global errorsoonser
    global errortype
    global road4
    road4 = 0
    failfail=None
    winsound.PlaySound(None, winsound.SND_ASYNC)
    winsound.PlaySound(failfail, winsound.SND_ASYNC)
    if os.path.exists('Others/a' + username + 'fn.txt') == False:
        failnum = open('Others/a' + username + 'fn.txt', 'w')
        startingnum = '1'
        failnum.write(startingnum)
        failnum.close()
    if os.path.exists('Others/a' + username + 'fn.txt') == True:
        failnum = open('Others/a' + username + 'fn.txt', 'r+')
        failnumbers = failnum.read()
        failnumbers = float(failnumbers)
        failnumbers += 1
        failnumbers = str(failnumbers)
        failnum.write(failnumbers)
        failnum.close()
    sc.game(readv, "You have failed")
    sc.game(readv, "Do you want to restart from the previous save?")
    sc.game(readv, "1)Yes, I want to restart from the previous save. \n2)No, I want to restart from the beggining. \n3)No, I want to stop playing.")
    restart2 = input("")
    if restart2=='2':
        chracterselect()
    if restart2=='1':
        failfail=False
    if restart2=='3':
        failfail=True
    else:
        while restart2!='1' and restart2!='2' and restart2!='3':
            sc.game(readv, "Choose a valid answer")
            sc.game(readv, "Do you want to restart from the previous save?")
            sc.game(readv, "1)Yes, I want to restart from the previous save. \n2)No, I want to restart from the beggining. \n3)No, I want to stop playing.")
            restart2 = input("")
            if restart2=='2':
                chracterselect()
            elif restart2=='1':
                failfail=False
            elif restart2=='3':
                failfail=True
    if failfail==False:
        direction()
    if failfail==True:
        exit()
    else:
        errorsoonser = 13
        errortype = 'A'
        endtime = tom.time()

def endingscreen():
    winsound.PlaySound(endcredit, winsound.SND_ASYNC)
    sc.game(readv, user + ", You have saved Pont-Évêque")
    sc.game(readv, "Monsters in the dungeon would have invaded Pont-Évêque if you did not closed the dungeon.")
    if neighbor=='Died':
        sc.game(readv, "You couldn't save " + neighbor + " but you can't save everyone all the time.")
    if dadd=='Died' and neighbor!='Died':
        sc.game(readv, "You killed your dad but everyone will understand your decision.")
    if neighbor=='Died' and dadd=='Died':
        sc.game(readv, "You also killed your dad but everyone will understand your decision.")
    sc.game(readv, "Your name will be remembered for centuries")
    sc.game(readv, "Well done " + user)
    sc.game(readv, "Do you want to see the end credits? \n1)Yes \n2)No")
    endcrecho = input("")
    if endcrecho=='1':
        endingcredit()
    elif endcrecho=='2':
        sc.game(readv, "Ok, Thanks for playing our game " + user)
        sc.game(readv, "Press enter to exit the game.")
        input("")
        exit()
    else:
        sc.game(readv, "Ok, I assume you don't want to see.")
        sc.game(readv, "Thanks for plaing our game " + user)
        sc.game(readv, "Press enter to exit the game.")
        input("")
        exit()

def endingcredit():
    sc.endc("\n\n\n\n\n")
    sc.endc("Made by Avocado \n")
    sc.endc("Manager: Jake \n")
    sc.endc("Head Game Designer: Jake \n")
    sc.endc("Game Designer: Tom \n")
    sc.endc("Logo Designer: Tom \n")
    sc.endc("UI Programmer: Liam \n")
    sc.endc("Sound Programmer: Tom \n")
    sc.endc("Head Gameplay Programmer: Jake \n")
    sc.endc("Gameplay Programmer: Liam \n")
    sc.endc("Gameplay Programmer: Tom \n")
    sc.endc("Head Level Designer: Jake \n")
    sc.endc("Level Designer: Tom \n")
    sc.endc("Tester1: Jake \n")
    sc.endc("Tester2: Tom \n")
    sc.endc("Avocado: Liam \n")
    if weapon=='Avocado':
        sc.endc("I love Tom :) - from Liam \n")
    sc.endc("French Dungeon 2: The return of " + chractername + "\n")
    tom.sleep(3)
    sc.game(readv, "Press enter to exit the game.")
    input("")
    exit()

"""
sc.game(readv, "Hello Do you want to make an account or log in")
login = input("")
if login==1:
    sc.game(readv, "What is your username")
    username = input("")
    f = open(username + '.txt', 'w')
    f.write(username)
"""




def login():
    global errorsoonser
    global errortype
    global endtime
    global username
    global user
    username = input("Type your username or type in '1' to go back to home menu. \n*If you forget your username, go to setting on home menu\n")
    if username=='1':
        print()
        lsjakea()
    user = username
    """try:"""
    if os.path.exists('Username/a' + username + 'un.txt') == False:
        while os.path.exists('Username/a' + username + 'un.txt')==False:
            print("That username does not exist in your folder")
            username = input("Type your username or type in '1' to go back to home menu. \n")
            if username==1:
                lsjakea()
    usernamef = open('Username/a' + username + 'un.txt', 'r')
    usercheck = usernamef.read()
    usernamef.close()
    if username==usercheck:
        password = input("Type your password or type in '1' to go back to home menu. \n")
        if password=='1':
            print()
            lsjakea()
        passwordf = open('Password/a' + username + 'pw.txt', 'r')
        passcheck = passwordf.read()
        ul = len(username)
        pl = len(passcheck)
        passcheck = eandc.dec(passcheck, ul, pl)
        passcheck = conv.convert(passcheck)
        passwordf.close()
        if password==passcheck and username=='immanuel':
            winsound.PlaySound(loginsfx, winsound.SND_ASYNC)
            print("Welcome developer!")
            devtool()
        if password==passcheck:
            print("Welcome " + username)
            winsound.PlaySound(loginsfx, winsound.SND_ASYNC)
            home()
        else:
            while password!=passcheck:
                print("That is wrong")
                password = input("Type your password again or type in '1' to go back to the home menu. \n*If you forget your username, go to the setting's on the home menu \n")
                if password=='1':
                    lsjakea()
            else:
                print("Welcome " + username)
                winsound.PlaySound(loginsfx, winsound.SND_ASYNC)
                home()
    """except:
        errorsoonser = 12
        errortype = 'S'
        endtime = tom.time()"""
                
def loading():
    global monsterk
    global errorsoonser
    global errortype
    global endtime
    global stagesave
    global hp
    global partyhp
    global weapon
    global damage
    global chracter
    global attS
    global road4
    global chracterquote
    global neighbor
    global neighborquote
    global chractername
    global chracter
    global readv
    """try:"""
    ssg = open('ProSave/a' + username + 'ps.txt', 'r+')
    stagesave = ssg.read()
    ssg.close()
    stagesave = float(stagesave)
    rt = open('Others/a' + username + 'rt.txt', 'r+')
    readv = rt.read()
    readv = float(readv)
    rt.close()
    if stagesave>0.1:
        hhp = open('Informations/a' + username + 'hp.txt', 'r+')
        hp = hhp.read()
        hp = float(hp)
        hhp.close()
        ivs.invlod(username)
        cc = open('Informations/a' + username + 'cc.txt', 'r+')
        chracter = int(cc.read())
        cc.close()
        if chracter==1:
            chracterquote='Croissant:'
            neighborquote='Ahh Choux:'
            chractername='Croissant'
        if chracter==2:
            chracterquote='Ficelle:'
            neighborquote='Bicotti Fontina:'
            chractername='Ficelle'
    if stagesave>4:
        nb = open('Informations/a' + username + 'nb.txt', 'r+')
        neighbor = nb.read()
        nb.close()
    if stagesave>4 and neighbor!='Died':
        php = open('Informations/a' + username + 'php.txt', 'r+')
        partyhp = php.read()
        partyhp = float(partyhp)
        php.close()
        if chracter==1:
            neighbor='Ahh Choux'
        if chracter==2:
            neighbor='Biscotti Fontina'
    if stagesave>1.5:
        wp = open('Informations/a' + username + 'wp.txt', 'r+')
        weapon = wp.read()
        wp.close()
        dam = open('Informations/a' + username + 'dg.txt', 'r+')
        damage = dam.read()
        damage = float(damage)
        dam.close()
        AS = open('Informations/a' + username + 'as.txt', 'r+')
        attS = AS.read()
        attS = float(attS)
        AS.close()
    if stagesave>6 and stagesave<7:
        rd4 = open('Others/a' + username + 'rd.txt', 'r+')
        road4 = rd4.read()
        road4 = int(road4)
        rd4.close()
    if neighbor=='Died':
        mk = open('Informations/a' + username + 'mk.txt', 'r+')
        monsterk = mk.read()
        mk.close()
    direction()
    """except:
        errorsoonser = 10
        errortype = 'L'
        endtime = tom.time()
        errorscreen()"""


def direction():
    global errorsoonser
    global errortype
    global endtime
    print()
    """try:"""
    if stagesave==0:
        tutorial()
    if stagesave==0.1:
        tutorial()
    if stagesave==0.2:
        storystory()
    if stagesave==1:
        storystorystory()
    if stagesave==1.1:
        storystorystorystory()
    if stagesave==1.2:
        storystorystorystorystory()
    if stagesave==1.3:
        sixstories()
    if stagesave==1.4:
        sevenstories()
    if stagesave==1.5:
        startingweapon()
    if stagesave==2:
        one()
    if stagesave==3:
        two()
    if stagesave==3.1:
        three()
    if stagesave==4:
        four()
    if stagesave==5:
        five()
    if stagesave==6:
        six()
    if stagesave==6.1 or stagesave==6.2 or stagesave==6.4:
        sixcheck(road4)
    if stagesave==7:
        seven()
    if stagesave==7.1:
        seventwo()
    if stagesave==8:
        sevenbeforelast()
    else:
        errorsoonser = 8
        errortype = 'C'
        endtime = tom.time()
        errorscreen()
    """except:
        errorsoonser = 7
        errortype = 'C'
        endtime = tom.time()
        errorscreen()"""

def signup():
    global errorsoonser
    global errortype
    global endtime
    global username
    global user
    username = input("Type your username or type in '1' to go back to home menu. \n*Username must be longer than 5 words and less than 32 words length \n")
    """try:"""
    gilui = len(username)
    if username=='1':
        print()
        lsjakea()
    elif gilui>=33:
        print("That is too long to be used as a username it needs to be less than 32 words")
        print()
        signup()
    elif gilui<=4:
        print("That is too short to be used as a username. It needs to be longer than 5 words")
        print()
        signup()
    if os.path.exists('Username/a' + username + 'un.txt')==True:
        while os.path.exists('Username/a' + username + 'un.txt')==True:
            print("Choose a different username it already exists")
            username = input("Type your username or type in '1' to go back to home menu.\n")
            if username==1:
                lsjakea()
    usernamef = open('Username/a' + username + 'un.txt', 'w')
    usernamef.write(username)
    usernamef.close()
    user = username
    ul = len(username)
    passworddef = eandc.randompassword(ul)
    passwordf = open('Password/a' + username + 'pw.txt', 'w')
    passwordf.write(passworddef)
    passwordf.close()
    pl = 1
    while pl<=7 or pl>=41:
        password = input("Type your password or type in '1' to go back to the home menu. \n*Password must be longer than 8 words and less than 40 words in length \n")
        pl = len(password)
        if password=='1':
            print()
            lsjakea()
        elif pl>=41:
            print("That is too long to be used as a password it needs to be less than 40 words")
            print()
        elif pl<=7:
            print("That is too short to be used as a password. It needs to be longer than 8 words")
            print()
        else:
            break
    """try:"""
    passwordenc = eandc.enc(password, ul, pl)
    """except:
        errorsoonser = 11
        errortype = 'S'
        endtime = tom.time()
        errorscreen()"""
    passwordenc = conv.convert(passwordenc)
    passwordf = open('Password/a' + username + 'pw.txt', 'w')
    passwordf.write(passwordenc)
    passwordf.close()
    winsound.PlaySound(loginsfx, winsound.SND_ASYNC)
    print("You have created an account \n")
    winsound.PlaySound(loginsfx, winsound.SND_ASYNC)
    home()
    """except:
        errorsoonser = 6
        errortype = 'S'
        endtime = tom.time()
        errorscreen()"""

#Encrypt
"""dsadsadasdas
def encrypt(text,s): 
    result = "" 
  
    # traverse text 
    for i in range(len(text)): 
        char = text[i] 
  
        # Encrypt uppercase characters 
        if (char.isupper()): 
            result += chr((ord(char) + s-65) % 26 + 65) 
  
        # Encrypt lowercase characters 
        else: 
            result += chr((ord(char) + s - 97) % 26 + 97) 
  
    return result 
  
#check the above function 
text = "ATTACKATONCE"
s = 4
sc.game "Text  : " + text 
sc.game "Shift : " + str(s) 
sc.game "Cipher: " + encrypt(text,s) 
"""

def lsjakea():
    global endtime
    global errorsoonser
    global errortype
    global readv
    winsound.PlaySound(homemenu, winsound.SND_ASYNC + winsound.SND_LOOP)
    lsjake = None
    while lsjake!='1' or lsjakea!='2' or lsjakea!='3':
        lsjake = input("What do you want to do? \n1)Login \n2)Signup \n3)View the settings \n")
        if lsjake=='1':
            print()
            login()
        elif lsjake=='2':
            print()
            signup()
        elif lsjake=='3':
            print()
            presetting()
        else:
            print("Type a correct number")
            print()

def home():
    winsound.PlaySound(homemenu, winsound.SND_ASYNC + winsound.SND_LOOP)
    homejake = None
    if os.path.exists('ProSave/a' + username + 'ps.txt')==True:
        while homejake!='1' or homejake!='2' or homejake!='3':
            homejake = input("What do you want to do? \n1)Start a new game \n2)Load previous game \n3)View the settings \n")
            if homejake=='1':
                if os.path.exists('Others/a' + username + 'rt.txt')==True:
                    print()
                    rt = open('Others/a' + username + 'rt.txt', 'r+')
                    readv = rt.read()
                    readv = float(readv)
                    rt.close()
                    tutorial()
                else:
                    print()
                    readingtime()
            if homejake=='2':
                loading()
            if homejake=='3':
                setting()
            else:
                print("Choose a valid number.")
                print()
    while homejake!='1' or homejake!='2':
        homejake = input("What do you want to do? \n1)Start game \n2)View the  settings \n")
        if homejake=='1':
            if os.path.exists('Others/a' + username + 'rt.txt')==True:
                print()
                rt = open('Others/a' + username + 'rt.txt', 'r+')
                readv = rt.read()
                readv = float(readv)
                rt.close()
                tutorial()
            else:
                print()
                readingtime()
        if homejake=='2':
            print()
            setting()
        else:
            print("Choose a valid number.")
            print()

def presetting():
    global vvvvv
    presetch = None
    while presetch!='1' or presetch!='2' or presetch!='3' or presetch!='4':
        print("What do you want to do? \n1)Check the usernames in the game folder \n2)I forgot my password \n3)Check the game version \n4)Go back to the home menu \n")
        presetch = input("")
        if presetch=='1':
            userpath = 'Username/'
            userfile = os.listdir(userpath)
            usernumber = [file for file in userfile if file.endswith(".txt")]
            usernumber = len(usernumber)
            print("There are ", usernumber, "of saved accounts")
            for usernames in userfile:
                print(usernames)
            print("That is all")
            print()
            presetting()
        if presetch=='2':
            print("Type your username or type in '1' to cancel")
            username = input("")
            if username=='1':
                presetch()
            if os.path.exists('Username/a' + username + 'un.txt') == False:
                while os.path.exists('Username/a' + username + 'un.txt')==False:
                    print("That username does not exist in your folder")
                    username = input("Type your username or type in '1' to cancel. \n")
                    if username=='1':
                        presetch()
                    else:
                        break
            ul = len(username)
            print("To change your password, Send the line under it to here > choj@stu.otc.school.nz")
            userenc = eandc.enc(username, ul, 3)
            passf = open("Password/a" + username + "pw.txt", "r")
            passw = passf.read()
            passf.close()
            userenc = conv.convert(userenc)
            outtext = userenc + " - " + passw
            print(outtext)
            presetting()
        if presetch=='3':
            vvvvv = str(vvvvv)
            print("The current game version is: v." + vvvvv)
            vvvvv = float(vvvvv)
            print()
            presetting()
        if presetch=='4':
            print()
            lsjakea()
        else:
            print("Choose a valid number.")
            print()
    lsjakea()

def setting():
    global errorsoonser
    global errortype
    global endtime
    global readv
    setch = None
    if os.path.exists('Others/a' + username + 'rt.txt')==True:
        while setch!='1' or setch!='2' or setch!='3' or setch!='4' or setch!='5' or setch!='6':
            print("What do you want to do? \n1)Change password \n2)Change text speed \n3)Look at your statistics \n4)Reset progress \n5)Check the game version \n6)Go back to the home menu")
            setch = input("")
            if setch=='1':
                psps = 'Nothing'
                passcheck = 'It is nothing'
                ul = len(username)
                while psps!=passcheck:
                    print("Type your current password or press '1' to cancel")
                    psps = input("")
                    if psps=='1':
                        setting()
                    passwordf = open('Password/a' + username + 'pw.txt', 'r')
                    passcheck = passwordf.read()
                    passwordf.close()
                    pl = len(passcheck)
                    passcheck = eandc.dec(passcheck, ul, pl)
                    passcheck = conv.convert(passcheck)
                    if psps!=passcheck:
                        print("That password is wrong")
                    if psps==passcheck:
                        break
                    else:
                        errorsoonser = 19
                        errortype = 'A'
                        endtime = tom.time()
                        errorscreen()
                npl = 0
                while npl<=7 or npl>=41:
                    npw = input("Type in a new password or press '1' to cancel \n*Password must be longer than 8 words and less than 40 words length \n")
                    npl = len(npw)
                    if npw=='1':
                        print()
                        setting()
                    elif npl<=7:
                        print("That password is too short, it needs to be longer than 8 words")
                        print()
                    elif npl>=41:
                        print("That password is too long, it needs to be shorter than 40 words")
                        print()
                    else:
                        break
                passwordf = open('Password/a' + username + 'pw.txt', 'r+')
                npl = len(npw)
                nnpw = eandc.enc(npw, ul, npl)
                passwordf.write(nnpw)
                passwordf.close()
                print("Your password has been changed!")
                print()
                setting()
            if setch=='2':
                rt = open('Others/a' + username + 'rt.txt', 'r+')
                readv = rt.read()
                readv = float(readv)
                rt.close()
                readvvv = None
                while readvvv!='1' or readvvv!='2':
                    sc.game(readv, "This is your previous text speed.")
                    sc.game(readv, "Enter '1' to cancel and '2' to change the text speed")
                    readvvv = input("")
                    if readvvv=='1':
                        setting()
                    if readvvv=='2':
                        break
                    else:
                        print("Type a valid number in")
                        print()
                readvvvv = None
                while readvvvv!='1':
                    sc.game(readv, "Enter '+' to speed up, '-' to slow down and '1' to confrim.")
                    readvv = input("")
                    if readvvvv=='1':
                        break
                    if readvvvv=='-':
                        readv = readv * 1.2
                    if readvvvv=='+':
                        readv = readv * 0.8
                    else:
                        sc.game(readv, "Type a valid answer.")
                rt = open('Others/a' + username + 'rt.txt', 'w')
                rt.write(str(readv))
                rt.close()
                sc.game(readv, "This is the text speed now >w<")
                print()
                setting()
            if setch=='3':
                if os.path.exists('Informations/a' + username + 'cc.txt')==True:
                    cc = open('Informations/a' + username + 'cc.txt', 'r')
                    chracter = int(cc.read())
                    cc.close()
                    if chracter==1:
                        print("Your character is Croissant Chocolat Cantel")
                    if chracter==2:
                        print("Your character is ")
                if os.path.exists('Informations/a' + username + 'hp.txt')==True:
                    hhp = open('Informations/a' + username + 'hp.txt', 'r')
                    hp = hhp.read()
                    hhp.close()
                    ivs.invsav(inventory, username)
                    print("HP: " + hp)
                    hp = float(hp)
                if os.path.exists('Informations/a' + username + 'wp.txt')==True:
                    wp = open('Informations/a' + username + 'wp.txt', 'r')
                    weapon = wp.read()
                    wp.close()
                    print("You have chosen " + wp + " as your weapon.")
                if os.path.exists('Informations/a' + username + 'dam.txt')==True:
                    dam = open('Informations/a' + username + 'dg.txt', 'r')
                    damage = dam.read()
                    dam.close()
                    print("And the weapon you have does " + damage + " damage!")
                    damage = float(damage)
                    if damage>3:
                        print("That weapon is great!")
                if os.path.exists('Informations/a' + username + 'as.txt')==True:
                    AS = open('Informations/a' + username + 'as.txt', 'r')
                    attS = AS.read()
                    AS.close()
                    print("Your attack speed is " + attS + ".")
                    print("That is way faster than troll!")
                    attS = float(attS)
                if os.path.exists('Others/a' + username + 'fn.txt')==True:
                    failnum = open('Others/a' + username + 'fn.txt', 'r')
                    failnumbers = failnum.read()
                    failnum.close()
                    print("You have failed " + failnumbers + " times!")
                    failnumbers = float(failnumbers)
                    if failnumbers>5 and failnumbers<50:
                        print("You have failed less than Liam but more than Tom!")
                print("Those were all the statistics for your game!")
                print()
                setting()
            if setch=='4':
                if os.path.exists('ProSave/a' + username + 'ps.txt')==True:
                    os.remove('ProSave/a' + username + 'ps.txt')
                if os.path.exists('Others/a' + username + 'rt.txt')==True:
                    os.remove('Others/a' + username + 'rt.txt')
                if os.path.exists('Informations/a' + username + 'hp.txt')==True:
                    os.remove('Informations/a' + username + 'hp.txt')
                if os.path.exists('InvSave/a' + username + 'iv.txt')==True:
                    os.remove('InvSave/a' + username + 'iv.txt')
                if os.path.exists('Informations/a' + username + 'cc.txt')==True:
                    os.remove('Informations/a' + username + 'cc.txt')
                if os.path.exists('Informations/a' + username + 'nb.txt')==True:
                    os.remove('Informations/a' + username + 'nb.txt')
                if os.path.exists('Informations/a' + username + 'php.txt')==True:
                    os.remove('Informations/a' + username + 'php.txt')
                if os.path.exists('Informations/a' + username + 'wp.txt')==True:
                    os.remove('Informations/a' + username + 'wp.txt')
                if os.path.exists('Informations/a' + username + 'dg.txt')==True:
                    os.remove('Informations/a' + username + 'dg.txt')
                if os.path.exists('Informations/a' + username + 'as.txt')==True:
                    os.remove('Informations/a' + username + 'as.txt')
                if os.path.exists('Others/a' + username + 'rd.txt')==True:
                    os.remove('Others/a' + username + 'rd.txt')
                if os.path.exists('Informations/a' + username + 'mk.txt')==True:
                    os.remove('Informations/a' + username + 'mk.txt')
                print("Your progress is successfully resetted")
                print()
                setting()
            if setch=='5':
                vvvvv = str(vvvvv)
                print("The current game version is: v." + vvvvv)
                vvvvv = float(vvvvv)
                print()
                setting()
            if setch=='6':
                print()
                home()
            else:
                print("Choose a valid number")
                print()
    else:
        while setch!='1' or setch!='2' or setch!='3':
            print("What do you want to do? \n1)Change your password \n2)Check the game version \n3)Go back to the home menu")
            setch = input("")
            if setch=='1':
                psps = 'Nothing'
                passcheck = 'It is nothing'
                ul = len(username)
                while psps!=passcheck:
                    print("Type your current password or press '1' to cancel")
                    psps = input("")
                    if psps=='1':
                        setting()
                    passwordf = open('Password/a' + username + 'pw.txt', 'r')
                    passcheck = passwordf.read()
                    passwordf.close()
                    pl = len(passcheck)
                    passcheck = eandc.dec(passcheck, ul, pl)
                    passcheck = conv.convert(passcheck)
                    if psps!=passcheck:
                        print("That password is wrong")
                    if psps==passcheck:
                        break
                    else:
                        errorsoonser = 19
                        errortype = 'A'
                        endtime = tom.time()
                        errorscreen()
                npl = 0
                while npl<=7 or npl>=41:
                    npw = input("Type in a new password or press '1' to cancel \n*Password must be longer than 8 words and less than 40 words in length \n")
                    npl = len(npw)
                    if npw=='1':
                        print()
                        setting()
                    elif npl<=7:
                        print("That password is too short, it needs to be longer than 8 words")
                        print()
                    elif npl>=41:
                        print("That password is too long, it needs to be shorter than 40 words")
                        print()
                    else:
                        break
                passwordf = open('Password/a' + username + 'pw.txt', 'r+')
                npl = len(npw)
                nnpw = eandc.enc(npw, ul, npl)
                passwordf.write(nnpw)
                passwordf.close()
                print("Your password is changed!")
                print()
                setting()
            if setch=='2':
                vvvvv = str(vvvvv)
                print("The current game version is: v." + vvvvv)
                vvvvv = float(vvvvv)
                print()
                setting()
            if setch=='3':
                print()
                home()
            else:
                print("Choose a valid number")
                print()

def filescheck():
    if os.path.exists('./Music')==False:
        os.mkdir('./Music')
    if os.path.exists('./Password')==False:
        os.mkdir('./Password')
    if os.path.exists('./Username')==False:
        os.mkdir('./Username')
    if os.path.exists('./ProSave')==False:
        os.mkdir('./ProSave')
    if os.path.exists('./Informations')==False:
        os.mkdir('./Informations')
    if os.path.exists('./Others')==False:
        os.mkdir('./Others')
    lsjakea()

def devtool():
    developmenta = input("Hello developer \nversion \nexit \ndeveloper \nstage \nerrorcodebook \n")
    if developmenta=='version':
        input(vvvvv)
    if developmenta=='exit':
        exit()
    if developmenta=='developer':
        print(currentdeveloper)
    if developmenta=='errorcodebook':
        errorcodebook={'A':'error happened where it should not happen', 'B':'Error occured during the battle part', 'C':'Error occured during redirect to other section', 'D':'Error during using a development tool', 'L':'Error while loading a user information', 'S':'Error during login or signup', 'T':'Testing it'}
        aabbccddeeffgg = input("Put in the error type or type '1' in to check how to read error code \n")
        if aabbccddeeffgg=='1':
            ECG.dev()
            input("")
            exit()
        if aabbccddeeffgg in errorcodebook==True:
            print(errorcodebook[aabbccddeeffgg])
        else:
            errorsoonser = 4
            errortype = 'D'
            endtime = tom.time()
            endtime = tom.time()
    if developmenta=='stage':
        import types
        print([f for f in globals().values() if type(f) == types.FunctionType])
        stageselect = input("Which stage do you want to go to? press 1 to cancel\n")
        """try:"""
        if stageselect=='1':
            lsjakea()
        if stageselect=='errorscreen':
            errorsoonser = 1
            errortype = 'T'
            endtime = tom.time()
        if stageselect in locals():
            func = locals()[stagesave]
            func()
        """except:
            errorsoonser = 5
            errortype = 'D'
            endtime = tom.time()
            errorscreen()"""
    else:
        errorsoonser = 9
        errortype = 'D'
        endtime = tom.time()
        errorscreen()

def errorscreen():
    errortime = endtime - starttime
    errorcode = ECG.oryu(errorsoonser, errortype, errortime, stagesave)
    print("Error occured\n")
    print("Pls report this to developer with errorcode underneath\n")
    print("You can contact us through this email address\n")
    print("choj@stu.otc.school.nz\n")
    print("I'm sorry\n")
    print("Error code: " + errorcode + "\n")
    input("Press enter to turn the program off")
    sys.exit()

filescheck()
"""
window.mainloop()
"""
