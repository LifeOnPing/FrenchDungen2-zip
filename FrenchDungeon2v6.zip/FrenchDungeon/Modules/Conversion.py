def convert(text): 
  

    texta = "" 
  
    return(texta.join(text)) 