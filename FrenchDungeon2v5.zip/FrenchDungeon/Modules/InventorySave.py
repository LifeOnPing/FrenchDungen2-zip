def invsav(inventory, username):
    inv = open('InvSave/a' + username + 'iv.txt', 'w')
    for items in inventory:
        inv.write(items + ",")
    inv.close()
    
def invlod(username):
    inv = open('InvSave/a' + username + 'iv.txt', 'r')
    invinv = inv.read()
    inv.close()
    invinv = invinv[0:-1]
    inv = open('InvSave/a' + username + 'iv.txt', 'w')
    inv.write(invinv)
    inv.close()
    inv = open('InvSave/a' + username + 'iv.txt', "r")
    invinvinv=inv.read()
    inv.close()
    iiii = invinvinv.split(',')
    return iiii